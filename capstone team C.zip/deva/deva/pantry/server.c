#ifdef _WIN32
    #define _WIN32_WINNT 0x0600
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <windows.h>
    #pragma comment(lib, "ws2_32.lib")

    typedef SOCKET socket_t;
    #define socket_close(s) closesocket(s)
    #define IS_INVALID_SOCKET(s) ((s) == INVALID_SOCKET)
#else
    #define _POSIX_C_SOURCE 200112L
    #include <unistd.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <pthread.h>
    #include <fcntl.h>
    #include <sys/stat.h>

    typedef int socket_t;
    #define socket_close(s) close(s)
    #define IS_INVALID_SOCKET(s) ((s) < 0)
    #define INVALID_SOCKET (-1)
    #define SOCKET_ERROR   (-1)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "recipes.h"
#include "matcher.h"
#include "persistence.h"
#include "json_parser.h"

#define SERVER_PORT        8080
#define RECV_BUFFER_SIZE   65536
#define SEND_BUFFER_SIZE   (1 << 20)
#define HTML_FILE_NAME     "pantry_quest.html"

static RecipeDB global_db;

static void *handle_client(void *arg);

#ifdef _WIN32
static DWORD WINAPI client_thread_entry(LPVOID arg)
{
    handle_client(arg);
    return 0;
}
#endif

static const char *diet_to_string(DietType d)
{
    if (d == NON_VEG) return "non-veg";
    if (d == VEGAN)   return "vegan";
    return "veg";
}

static const char *meal_to_string(MealType m)
{
    if (m == BREAKFAST)   return "breakfast";
    if (m == SNACK)       return "snack";
    if (m == DESSERT)     return "dessert";
    return "main_course";
}

static const char *cuisine_to_string(Cuisine c)
{
    if (c == SOUTH_INDIAN) return "South Indian";
    if (c == EAST_INDIAN)  return "East Indian";
    if (c == WEST_INDIAN)  return "West Indian";
    if (c == PAN_INDIAN)   return "Pan Indian";
    return "North Indian";
}

static void json_escape_string(const char *input, char *output, int max_len)
{
    int out_pos = 0;
    for (int i = 0; input[i] && out_pos < max_len - 2; i++) {
        unsigned char ch = (unsigned char)input[i];
        if (ch == '"') {
            if (out_pos < max_len - 2) { output[out_pos++] = '\\'; output[out_pos++] = '"'; }
        } else if (ch == '\\') {
            if (out_pos < max_len - 2) { output[out_pos++] = '\\'; output[out_pos++] = '\\'; }
        } else if (ch == '\n') {
            if (out_pos < max_len - 2) { output[out_pos++] = '\\'; output[out_pos++] = 'n'; }
        } else if (ch == '\r') {
            if (out_pos < max_len - 2) { output[out_pos++] = '\\'; output[out_pos++] = 'r'; }
        } else if (ch == '\t') {
            if (out_pos < max_len - 2) { output[out_pos++] = '\\'; output[out_pos++] = 't'; }
        } else {
            output[out_pos++] = (char)ch;
        }
    }
    output[out_pos] = '\0';
}

static void scale_quantity(const char *original, double scale, char *result, int max_len)
{
    char *end;
    double value = strtod(original, &end);
    if (end == original || scale <= 0.0) {
        strncpy(result, original, max_len - 1);
        result[max_len - 1] = '\0';
        return;
    }
    double scaled_value = value * scale;
    if (scaled_value == (long long)scaled_value) {
        snprintf(result, max_len, "%lld%s", (long long)scaled_value, end);
    } else {
        snprintf(result, max_len, "%.1f%s", scaled_value, end);
    }
}

static int append_ingredient_json(char *buf, int pos, int max_len,
                                   Ingredient *ing, double scale)
{
    char escaped_name[MAX_NAME_LEN * 2];
    char escaped_qty[MAX_QTY_LEN * 2];
    char scaled_qty[MAX_QTY_LEN];

    json_escape_string(ing->name, escaped_name, sizeof(escaped_name));
    scale_quantity(ing->quantity, scale, scaled_qty, MAX_QTY_LEN);
    json_escape_string(scaled_qty, escaped_qty, sizeof(escaped_qty));

    pos += snprintf(buf + pos, max_len - pos,
        "{\"name\":\"%s\",\"quantity\":\"%s\",\"is_staple\":%d}",
        escaped_name, escaped_qty, ing->is_staple);
    return pos;
}

static int recipe_to_json_summary(Recipe *r, char *buf, int max_len)
{
    char esc_name[MAX_NAME_LEN * 2];
    char esc_desc[MAX_STR_LEN * 2];
    json_escape_string(r->name, esc_name, sizeof(esc_name));
    json_escape_string(r->description, esc_desc, sizeof(esc_desc));

    int pos = snprintf(buf, max_len,
        "{\"id\":%d,\"name\":\"%s\",\"description\":\"%s\","
        "\"diet\":\"%s\",\"meal\":\"%s\",\"cuisine\":\"%s\","
        "\"prep_time\":%d,\"cook_time\":%d,\"default_servings\":%d,"
        "\"ingredient_count\":%d}",
        r->id, esc_name, esc_desc,
        diet_to_string(r->diet), meal_to_string(r->meal), cuisine_to_string(r->cuisine),
        r->prep_time_min, r->cook_time_min, r->default_servings,
        r->ingredient_count);
    return pos;
}

static int recipe_to_json_full(Recipe *r, double scale, char *buf, int max_len)
{
    char esc_name[MAX_NAME_LEN * 2];
    char esc_desc[MAX_STR_LEN * 2];
    json_escape_string(r->name, esc_name, sizeof(esc_name));
    json_escape_string(r->description, esc_desc, sizeof(esc_desc));

    int pos = snprintf(buf, max_len,
        "{\"id\":%d,\"name\":\"%s\",\"description\":\"%s\","
        "\"diet\":\"%s\",\"meal\":\"%s\",\"cuisine\":\"%s\","
        "\"prep_time\":%d,\"cook_time\":%d,"
        "\"default_servings\":%d,\"scale\":%.2f,",
        r->id, esc_name, esc_desc,
        diet_to_string(r->diet), meal_to_string(r->meal), cuisine_to_string(r->cuisine),
        r->prep_time_min, r->cook_time_min, r->default_servings, scale);

    pos += snprintf(buf + pos, max_len - pos, "\"ingredients\":[");
    for (int i = 0; i < r->ingredient_count && pos < max_len - 10; i++) {
        if (i > 0) buf[pos++] = ',';
        pos = append_ingredient_json(buf, pos, max_len, &r->ingredients[i], scale);
    }
    pos += snprintf(buf + pos, max_len - pos, "],\"steps\":[");
    for (int i = 0; i < r->step_count && pos < max_len - 10; i++) {
        char esc_step[MAX_STEP_LEN * 2];
        json_escape_string(r->steps[i], esc_step, sizeof(esc_step));
        pos += snprintf(buf + pos, max_len - pos, "%s\"%s\"", (i > 0 ? "," : ""), esc_step);
    }
    pos += snprintf(buf + pos, max_len - pos, "],\"tags\":[");
    for (int i = 0; i < r->tag_count && pos < max_len - 10; i++) {
        char esc_tag[128];
        json_escape_string(r->tags[i], esc_tag, sizeof(esc_tag));
        pos += snprintf(buf + pos, max_len - pos, "%s\"%s\"", (i > 0 ? "," : ""), esc_tag);
    }
    pos += snprintf(buf + pos, max_len - pos, "]}");
    return pos;
}

static void send_http_response(socket_t client_fd, int status_code, const char *status_text,
                                const char *content_type, const char *body, int body_len)
{
    char header[512];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n\r\n",
        status_code, status_text, content_type, body_len);
    send(client_fd, header, header_len, 0);
    if (body && body_len > 0) {
        send(client_fd, body, body_len, 0);
    }
}

static void handle_get_recipes(socket_t client_fd)
{
    char *body = malloc(SEND_BUFFER_SIZE);
    if (!body) { send_http_response(client_fd, 500, "Internal Server Error", "application/json", "{\"error\":\"OOM\"}", 15); return; }

    int pos = snprintf(body, SEND_BUFFER_SIZE, "{\"recipes\":[");
    for (int i = 0; i < global_db.count; i++) {
        if (i > 0) body[pos++] = ',';
        char summary[2048];
        recipe_to_json_summary(&global_db.recipes[i], summary, sizeof(summary));
        int slen = (int)strlen(summary);
        if (pos + slen < SEND_BUFFER_SIZE - 32) {
            memcpy(body + pos, summary, slen);
            pos += slen;
        }
    }
    pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "],\"total\":%d}", global_db.count);

    send_http_response(client_fd, 200, "OK", "application/json", body, pos);
    free(body);
}

static void handle_get_recipe_by_id(socket_t client_fd, int recipe_id, double scale)
{
    Recipe *found = NULL;
    for (int i = 0; i < global_db.count; i++) {
        if (global_db.recipes[i].id == recipe_id) {
            found = &global_db.recipes[i];
            break;
        }
    }
    if (!found) {
        send_http_response(client_fd, 404, "Not Found", "application/json", "{\"error\":\"Recipe not found\"}", 27);
        return;
    }
    char *body = malloc(SEND_BUFFER_SIZE);
    if (!body) { send_http_response(client_fd, 500, "Internal Server Error", "application/json", "{\"error\":\"OOM\"}", 15); return; }
    if (scale <= 0.0) scale = 1.0;
    int body_len = recipe_to_json_full(found, scale, body, SEND_BUFFER_SIZE);
    send_http_response(client_fd, 200, "OK", "application/json", body, body_len);
    free(body);
}

static void handle_post_match(socket_t client_fd, const char *request_body)
{
    PantryQuery query;
    memset(&query, 0, sizeof(PantryQuery));

    char ingredient_values[MAX_PANTRY_ITEMS][128];
    int ingredient_count = 0;
    json_get_string_array(request_body, "ingredients", ingredient_values, MAX_PANTRY_ITEMS, &ingredient_count);
    for (int i = 0; i < ingredient_count && i < MAX_PANTRY_ITEMS; i++) {
        strncpy(query.items[i], ingredient_values[i], MAX_NAME_LEN - 1);
        query.count++;
    }

    char diet_str[32] = "";
    if (json_get_string(request_body, "diet", diet_str, 32) && strlen(diet_str) > 0) {
        if (strcmp(diet_str, "veg") == 0) { query.diet_filter = VEG; query.has_diet_filter = 1; }
        else if (strcmp(diet_str, "non-veg") == 0) { query.diet_filter = NON_VEG; query.has_diet_filter = 1; }
        else if (strcmp(diet_str, "vegan") == 0) { query.diet_filter = VEGAN; query.has_diet_filter = 1; }
    }

    char meal_str[32] = "";
    if (json_get_string(request_body, "meal", meal_str, 32) && strlen(meal_str) > 0) {
        if (strcmp(meal_str, "breakfast") == 0) { query.meal_filter = BREAKFAST; query.has_meal_filter = 1; }
        else if (strcmp(meal_str, "main_course") == 0) { query.meal_filter = MAIN_COURSE; query.has_meal_filter = 1; }
        else if (strcmp(meal_str, "snack") == 0) { query.meal_filter = SNACK; query.has_meal_filter = 1; }
    }

    MatchResult results[MAX_RECIPES];
    int result_count = 0;
    match_recipes(&global_db, &query, results, &result_count);
    sort_results_by_match(results, result_count);

    char *body = malloc(SEND_BUFFER_SIZE);
    if (!body) { send_http_response(client_fd, 500, "Internal Server Error", "application/json", "{\"error\":\"OOM\"}", 15); return; }

    int pos = snprintf(body, SEND_BUFFER_SIZE, "{\"results\":[");
    for (int i = 0; i < result_count; i++) {
        MatchResult *mr = &results[i];
        if (i > 0) body[pos++] = ',';

        char esc_name[MAX_NAME_LEN * 2];
        json_escape_string(mr->recipe_name, esc_name, sizeof(esc_name));

        pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos,
            "{\"id\":%d,\"name\":\"%s\",\"match_percentage\":%.1f,"
            "\"match_count\":%d,\"total_ingredients\":%d,"
            "\"diet\":\"%s\",\"meal\":\"%s\",\"cuisine\":\"%s\","
            "\"prep_time\":%d,\"cook_time\":%d,",
            mr->recipe_id, esc_name, mr->match_percentage,
            mr->match_count, mr->total_non_staple_ingredients,
            diet_to_string(mr->diet), meal_to_string(mr->meal),
            cuisine_to_string(mr->cuisine),
            mr->prep_time_min, mr->cook_time_min);

        pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "\"matched\":[");
        for (int m = 0; m < mr->matched_count; m++) {
            char esc_m[MAX_NAME_LEN * 2];
            json_escape_string(mr->matched[m], esc_m, sizeof(esc_m));
            pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "%s\"%s\"", (m > 0 ? "," : ""), esc_m);
        }
        pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "],\"missing\":[");
        for (int m = 0; m < mr->missing_count; m++) {
            char esc_m[MAX_NAME_LEN * 2];
            json_escape_string(mr->missing[m], esc_m, sizeof(esc_m));
            pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "%s\"%s\"", (m > 0 ? "," : ""), esc_m);
        }
        pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "]}");
    }
    pos += snprintf(body + pos, SEND_BUFFER_SIZE - pos, "],\"total\":%d}", result_count);

    send_http_response(client_fd, 200, "OK", "application/json", body, pos);
    free(body);
}

static void handle_get_pantry(socket_t client_fd)
{
    char items[MAX_PANTRY_ITEMS][128];
    int count = load_pantry_from_file(items, MAX_PANTRY_ITEMS);

    char body[8192];
    int pos = snprintf(body, sizeof(body), "{\"pantry\":[");
    for (int i = 0; i < count; i++) {
        char escaped[256];
        json_escape_string(items[i], escaped, sizeof(escaped));
        pos += snprintf(body + pos, sizeof(body) - pos, "%s\"%s\"", (i > 0 ? "," : ""), escaped);
    }
    pos += snprintf(body + pos, sizeof(body) - pos, "],\"count\":%d}", count);
    send_http_response(client_fd, 200, "OK", "application/json", body, pos);
}

static void handle_post_pantry(socket_t client_fd, const char *request_body)
{
    char items[MAX_PANTRY_ITEMS][128];
    int count = 0;
    json_get_string_array(request_body, "pantry", items, MAX_PANTRY_ITEMS, &count);

    const char *item_ptrs[MAX_PANTRY_ITEMS];
    for (int i = 0; i < count; i++) item_ptrs[i] = items[i];
    save_pantry_to_file(item_ptrs, count);

    const char *ok = "{\"status\":\"saved\"}";
    send_http_response(client_fd, 200, "OK", "application/json", ok, (int)strlen(ok));
}

static void handle_post_custom_recipe(socket_t client_fd, const char *request_body)
{
    save_custom_recipe_json(request_body);
    load_custom_recipes(&global_db, global_db.count + 100);
    const char *ok = "{\"status\":\"saved\"}";
    send_http_response(client_fd, 200, "OK", "application/json", ok, (int)strlen(ok));
}

static void serve_html_file(socket_t client_fd)
{
    FILE *fp = fopen(HTML_FILE_NAME, "r");
    if (!fp) {
        const char *not_found = "<html><body><h1>pantry_quest.html not found</h1></body></html>";
        send_http_response(client_fd, 404, "Not Found", "text/html", not_found, (int)strlen(not_found));
        return;
    }
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    rewind(fp);

    char *html_buf = malloc((size_t)file_size + 1);
    if (!html_buf) { fclose(fp); return; }
    size_t bytes_read = fread(html_buf, 1, (size_t)file_size, fp);
    html_buf[bytes_read] = '\0';
    fclose(fp);

    send_http_response(client_fd, 200, "OK", "text/html; charset=utf-8", html_buf, (int)bytes_read);
    free(html_buf);
}

static void parse_query_param(const char *path, const char *param_name, char *out, int max_len)
{
    char search[128];
    snprintf(search, sizeof(search), "%s=", param_name);
    const char *pos = strstr(path, search);
    if (!pos) { out[0] = '\0'; return; }
    pos += strlen(search);
    int i = 0;
    while (*pos && *pos != '&' && *pos != ' ' && i < max_len - 1) {
        out[i++] = *pos++;
    }
    out[i] = '\0';
}

typedef struct {
    socket_t client_fd;
} ClientArg;

static void *handle_client(void *arg)
{
    ClientArg *ca = (ClientArg *)arg;
    socket_t client_fd = ca->client_fd;
    free(ca);

    char *recv_buf = malloc(RECV_BUFFER_SIZE);
    if (!recv_buf) { socket_close(client_fd); return NULL; }

    int bytes_received = recv(client_fd, recv_buf, RECV_BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) { free(recv_buf); socket_close(client_fd); return NULL; }
    recv_buf[bytes_received] = '\0';

    char method[16] = "";
    char path[512]  = "";
    sscanf(recv_buf, "%15s %511s", method, path);

    if (strcmp(method, "OPTIONS") == 0) {
        send_http_response(client_fd, 200, "OK", "application/json", "", 0);
        free(recv_buf); socket_close(client_fd); return NULL;
    }

    const char *body_start = strstr(recv_buf, "\r\n\r\n");
    const char *request_body = body_start ? body_start + 4 : "";

    if (strcmp(method, "GET") == 0 && (strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0)) {
        serve_html_file(client_fd);
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/api/recipes") == 0) {
        handle_get_recipes(client_fd);
    } else if (strcmp(method, "GET") == 0 && strncmp(path, "/api/recipe", 11) == 0) {
        char id_str[32], scale_str[32];
        parse_query_param(path, "id", id_str, sizeof(id_str));
        parse_query_param(path, "scale", scale_str, sizeof(scale_str));
        int recipe_id = id_str[0] ? atoi(id_str) : 0;
        double scale  = scale_str[0] ? atof(scale_str) : 1.0;
        handle_get_recipe_by_id(client_fd, recipe_id, scale);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/match") == 0) {
        handle_post_match(client_fd, request_body);
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/api/pantry") == 0) {
        handle_get_pantry(client_fd);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/pantry") == 0) {
        handle_post_pantry(client_fd, request_body);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/custom-recipe") == 0) {
        handle_post_custom_recipe(client_fd, request_body);
    } else {
        send_http_response(client_fd, 404, "Not Found", "application/json", "{\"error\":\"Not found\"}", 21);
    }

    free(recv_buf);
    socket_close(client_fd);
    return NULL;
}

int main(void)
{
#ifdef _WIN32
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        perror("WSAStartup");
        return 1;
    }
#endif

    init_recipe_db(&global_db);
    load_custom_recipes(&global_db, global_db.count + 100);

    socket_t server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (IS_INVALID_SOCKET(server_fd)) {
        perror("socket");
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

#ifdef _WIN32
    int option_reuse = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&option_reuse, sizeof(option_reuse));
#else
    int option_reuse = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &option_reuse, sizeof(option_reuse));
#endif

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family      = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port        = htons(SERVER_PORT);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        socket_close(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }
    if (listen(server_fd, 32) < 0) {
        perror("listen");
        socket_close(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

    printf("🍲 Pantry Quest Server running at http://localhost:%d\n", SERVER_PORT);
    printf("   Loaded %d recipes. Press Ctrl+C to stop.\n", global_db.count);
    fflush(stdout);

    while (1) {
        struct sockaddr_in client_addr;
#ifdef _WIN32
        int client_len = sizeof(client_addr);
#else
        socklen_t client_len = sizeof(client_addr);
#endif
        socket_t client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (IS_INVALID_SOCKET(client_fd)) continue;

        ClientArg *ca = malloc(sizeof(ClientArg));
        if (!ca) { socket_close(client_fd); continue; }
        ca->client_fd = client_fd;

#ifdef _WIN32
        HANDLE thread_handle = CreateThread(NULL, 0, client_thread_entry, ca, 0, NULL);
        if (thread_handle) {
            CloseHandle(thread_handle);
        } else {
            free(ca);
            socket_close(client_fd);
        }
#else
        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, handle_client, ca) != 0) {
            free(ca);
            socket_close(client_fd);
        } else {
            pthread_detach(thread_id);
        }
#endif
    }

    socket_close(server_fd);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
