#include "json_parser.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

static const char *find_key(const char *json, const char *key)
{
    char search[256];
    snprintf(search, sizeof(search), "\"%s\"", key);
    const char *pos = strstr(json, search);
    if (!pos) return NULL;
    pos += strlen(search);
    while (*pos == ' ' || *pos == '\t' || *pos == '\n' || *pos == '\r') pos++;
    if (*pos != ':') return NULL;
    pos++;
    while (*pos == ' ' || *pos == '\t' || *pos == '\n' || *pos == '\r') pos++;
    return pos;
}

static void unescape_json_string(const char *src, char *dst, int max_len)
{
    int di = 0;
    int i  = 0;
    while (src[i] && di < max_len - 1) {
        if (src[i] == '\\' && src[i + 1]) {
            i++;
            switch (src[i]) {
                case 'n':  dst[di++] = '\n'; break;
                case 't':  dst[di++] = '\t'; break;
                case 'r':  dst[di++] = '\r'; break;
                case '"':  dst[di++] = '"';  break;
                case '\\': dst[di++] = '\\'; break;
                default:   dst[di++] = src[i]; break;
            }
        } else {
            dst[di++] = src[i];
        }
        i++;
    }
    dst[di] = '\0';
}

int json_get_string(const char *json, const char *key, char *value, int max_len)
{
    const char *pos = find_key(json, key);
    if (!pos || *pos != '"') return 0;
    pos++;
    int i = 0;
    char raw[1024];
    while (*pos && *pos != '"' && i < (int)sizeof(raw) - 1) {
        if (*pos == '\\') {
            raw[i++] = *pos++;
            if (*pos) raw[i++] = *pos++;
        } else {
            raw[i++] = *pos++;
        }
    }
    raw[i] = '\0';
    unescape_json_string(raw, value, max_len);
    return 1;
}

int json_get_int(const char *json, const char *key, int *value)
{
    const char *pos = find_key(json, key);
    if (!pos) return 0;
    if (*pos == '"') { pos++; }
    char *end;
    long v = strtol(pos, &end, 10);
    if (end == pos) return 0;
    *value = (int)v;
    return 1;
}

int json_get_double(const char *json, const char *key, double *value)
{
    const char *pos = find_key(json, key);
    if (!pos) return 0;
    char *end;
    double v = strtod(pos, &end);
    if (end == pos) return 0;
    *value = v;
    return 1;
}

int json_get_string_array(const char *json, const char *key,
                          char values[][128], int max_values, int *count)
{
    *count = 0;
    const char *pos = find_key(json, key);
    if (!pos || *pos != '[') return 0;
    pos++;
    while (*pos && *count < max_values) {
        while (*pos == ' ' || *pos == '\t' || *pos == '\n' || *pos == '\r' || *pos == ',') pos++;
        if (*pos == ']') break;
        if (*pos == '"') {
            pos++;
            int i = 0;
            char raw[256];
            while (*pos && *pos != '"' && i < (int)sizeof(raw) - 1) {
                if (*pos == '\\') {
                    raw[i++] = *pos++;
                    if (*pos) raw[i++] = *pos++;
                } else {
                    raw[i++] = *pos++;
                }
            }
            raw[i] = '\0';
            unescape_json_string(raw, values[*count], 128);
            (*count)++;
            if (*pos == '"') pos++;
        } else {
            pos++;
        }
    }
    return 1;
}
