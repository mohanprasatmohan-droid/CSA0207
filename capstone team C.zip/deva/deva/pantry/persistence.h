#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include "recipes.h"

#define PANTRY_FILE         "pantry_data.json"
#define CUSTOM_RECIPES_FILE "custom_recipes.json"

void save_pantry_to_file(const char **items, int count);
int  load_pantry_from_file(char items[][128], int max_items);
void save_custom_recipe_json(const char *recipe_json);
int  load_custom_recipes(RecipeDB *db, int next_id);

#endif
