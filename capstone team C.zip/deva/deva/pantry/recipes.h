#ifndef RECIPES_H
#define RECIPES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_RECIPES      60
#define MAX_INGREDIENTS  20
#define MAX_STEPS        20
#define MAX_TAGS         8
#define MAX_ALIASES      4
#define MAX_NAME_LEN     128
#define MAX_STR_LEN      256
#define MAX_STEP_LEN     640
#define MAX_QTY_LEN      64

typedef enum { VEG = 0, NON_VEG = 1, VEGAN = 2 } DietType;
typedef enum { BREAKFAST = 0, MAIN_COURSE = 1, SNACK = 2, DESSERT = 3 } MealType;
typedef enum { NORTH_INDIAN = 0, SOUTH_INDIAN = 1, EAST_INDIAN = 2, WEST_INDIAN = 3, PAN_INDIAN = 4 } Cuisine;

typedef struct {
    char name[MAX_NAME_LEN];
    char quantity[MAX_QTY_LEN];
    char aliases[MAX_ALIASES][MAX_NAME_LEN];
    int  alias_count;
    int  is_staple;
} Ingredient;

typedef struct {
    int        id;
    char       name[MAX_NAME_LEN];
    char       description[MAX_STR_LEN];
    DietType   diet;
    MealType   meal;
    Cuisine    cuisine;
    int        prep_time_min;
    int        cook_time_min;
    int        default_servings;
    Ingredient ingredients[MAX_INGREDIENTS];
    int        ingredient_count;
    char       steps[MAX_STEPS][MAX_STEP_LEN];
    int        step_count;
    char       tags[MAX_TAGS][64];
    int        tag_count;
} Recipe;

typedef struct {
    Recipe recipes[MAX_RECIPES];
    int    count;
} RecipeDB;

void init_recipe_db(RecipeDB *db);
void add_recipe(RecipeDB *db, Recipe r);

#endif
