#ifndef MATCHER_H
#define MATCHER_H

#include "recipes.h"

#define MAX_PANTRY_ITEMS 50

typedef struct {
    int    recipe_id;
    char   recipe_name[MAX_NAME_LEN];
    int    match_count;
    int    total_non_staple_ingredients;
    double match_percentage;
    char   matched[MAX_INGREDIENTS][MAX_NAME_LEN];
    int    matched_count;
    char   missing[MAX_INGREDIENTS][MAX_NAME_LEN];
    int    missing_count;
    DietType diet;
    MealType meal;
    Cuisine  cuisine;
    int    prep_time_min;
    int    cook_time_min;
} MatchResult;

typedef struct {
    char items[MAX_PANTRY_ITEMS][MAX_NAME_LEN];
    int  count;
    DietType diet_filter;
    int  has_diet_filter;
    MealType meal_filter;
    int  has_meal_filter;
} PantryQuery;

int  ingredient_matches_pantry(Ingredient *ing, PantryQuery *query);
void match_recipes(RecipeDB *db, PantryQuery *query,
                   MatchResult *results, int *result_count);
void sort_results_by_match(MatchResult *results, int count);

#endif
