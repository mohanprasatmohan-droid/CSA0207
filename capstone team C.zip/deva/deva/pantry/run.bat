@echo off
setlocal enabledelayedexpansion

echo ========================================================
echo   Pantry Quest - Windows Build ^& Launch Script
echo ========================================================
echo.

where gcc >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] gcc was not found in your system PATH!
    echo Please install MinGW-w64 or MSYS2 and add its bin folder to PATH.
    echo Example:
    echo   C:\msys64\ucrt64\bin
    echo   C:\msys64\mingw64\bin
    echo.
    pause
    exit /b 1
)

echo [1/2] Compiling Pantry Quest for Windows (MinGW-w64)...
gcc -Wall -Wextra -std=c99 -o pantry_quest.exe server.c recipes.c matcher.c persistence.c json_parser.c -lws2_32

if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Compilation failed! Review the compiler errors above.
    pause
    exit /b %ERRORLEVEL%
)

echo [2/2] Build successful: pantry_quest.exe
echo.
echo Starting Pantry Quest Server at http://localhost:8080...
echo Opening browser... (Press Ctrl+C in this console window to stop server)
echo.

start "" "http://localhost:8080/"
pantry_quest.exe

endlocal
