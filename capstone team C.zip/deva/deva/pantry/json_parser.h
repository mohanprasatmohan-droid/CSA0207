#ifndef JSON_PARSER_H
#define JSON_PARSER_H

int json_get_string_array(const char *json, const char *key,
                          char values[][128], int max_values, int *count);
int json_get_string(const char *json, const char *key, char *value, int max_len);
int json_get_int(const char *json, const char *key, int *value);
int json_get_double(const char *json, const char *key, double *value);

#endif
