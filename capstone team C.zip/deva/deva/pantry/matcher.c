#include "matcher.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

static void to_lower(const char *src, char *dst, int max_len)
{
    int i = 0;
    while (src[i] && i < max_len - 1) {
        dst[i] = (char)tolower((unsigned char)src[i]);
        i++;
    }
    dst[i] = '\0';
}

static int strings_overlap(const char *haystack, const char *needle)
{
    char h[MAX_NAME_LEN], n[MAX_NAME_LEN];
    to_lower(haystack, h, MAX_NAME_LEN);
    to_lower(needle,   n, MAX_NAME_LEN);
    return strstr(h, n) != NULL || strstr(n, h) != NULL;
}

int ingredient_matches_pantry(Ingredient *ing, PantryQuery *query)
{
    for (int p = 0; p < query->count; p++) {
        if (strings_overlap(ing->name, query->items[p])) return 1;
        for (int a = 0; a < ing->alias_count; a++) {
            if (strings_overlap(ing->aliases[a], query->items[p])) return 1;
        }
    }
    return 0;
}

void match_recipes(RecipeDB *db, PantryQuery *query,
                   MatchResult *results, int *result_count)
{
    *result_count = 0;

    for (int r = 0; r < db->count; r++) {
        Recipe *recipe = &db->recipes[r];

        if (query->has_diet_filter && recipe->diet != query->diet_filter) continue;
        if (query->has_meal_filter && recipe->meal != query->meal_filter) continue;

        int non_staple_count = 0;
        int matched          = 0;
        MatchResult res;
        memset(&res, 0, sizeof(MatchResult));

        for (int i = 0; i < recipe->ingredient_count; i++) {
            Ingredient *ing = &recipe->ingredients[i];
            if (ing->is_staple) continue;
            non_staple_count++;

            if (ingredient_matches_pantry(ing, query)) {
                strncpy(res.matched[res.matched_count], ing->name, MAX_NAME_LEN - 1);
                res.matched_count++;
                matched++;
            } else {
                strncpy(res.missing[res.missing_count], ing->name, MAX_NAME_LEN - 1);
                res.missing_count++;
            }
        }

        if (non_staple_count == 0 || matched == 0) continue;

        res.recipe_id                = recipe->id;
        res.match_count              = matched;
        res.total_non_staple_ingredients = non_staple_count;
        res.match_percentage         = (double)matched / (double)non_staple_count * 100.0;
        res.diet                     = recipe->diet;
        res.meal                     = recipe->meal;
        res.cuisine                  = recipe->cuisine;
        res.prep_time_min            = recipe->prep_time_min;
        res.cook_time_min            = recipe->cook_time_min;
        strncpy(res.recipe_name, recipe->name, MAX_NAME_LEN - 1);

        results[(*result_count)++] = res;
        if (*result_count >= MAX_RECIPES) break;
    }
}

void sort_results_by_match(MatchResult *results, int count)
{
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            int swap = 0;
            if (results[j].match_percentage > results[i].match_percentage) {
                swap = 1;
            } else if (results[j].match_percentage == results[i].match_percentage &&
                       results[j].match_count > results[i].match_count) {
                swap = 1;
            }
            if (swap) {
                MatchResult tmp = results[i];
                results[i]      = results[j];
                results[j]      = tmp;
            }
        }
    }
}
