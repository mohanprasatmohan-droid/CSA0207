#include "persistence.h"
#include "json_parser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void save_pantry_to_file(const char **items, int count)
{
    FILE *fp = fopen(PANTRY_FILE, "w");
    if (!fp) return;

    fprintf(fp, "[\n");
    for (int i = 0; i < count; i++) {
        fprintf(fp, "  \"%s\"%s\n", items[i], (i < count - 1) ? "," : "");
    }
    fprintf(fp, "]\n");
    fclose(fp);
}

int load_pantry_from_file(char items[][128], int max_items)
{
    FILE *fp = fopen(PANTRY_FILE, "r");
    if (!fp) return 0;

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    rewind(fp);

    if (file_size <= 0 || file_size > 65536) {
        fclose(fp);
        return 0;
    }

    char *buffer = malloc((size_t)file_size + 1);
    if (!buffer) { fclose(fp); return 0; }

    size_t bytes_read = fread(buffer, 1, (size_t)file_size, fp);
    buffer[bytes_read] = '\0';
    fclose(fp);

    int count = 0;
    char *pos = buffer;
    while (*pos && count < max_items) {
        while (*pos && *pos != '"') pos++;
        if (!*pos) break;
        pos++;
        int i = 0;
        while (*pos && *pos != '"' && i < 127) {
            items[count][i++] = *pos++;
        }
        items[count][i] = '\0';
        if (i > 0) count++;
        if (*pos == '"') pos++;
    }

    free(buffer);
    return count;
}

void save_custom_recipe_json(const char *recipe_json)
{
    FILE *fp = fopen(CUSTOM_RECIPES_FILE, "r");
    char *existing = NULL;
    long file_size = 0;

    if (fp) {
        fseek(fp, 0, SEEK_END);
        file_size = ftell(fp);
        rewind(fp);
        if (file_size > 0 && file_size < 1048576) {
            existing = malloc((size_t)file_size + 1);
            if (existing) {
                size_t bytes = fread(existing, 1, (size_t)file_size, fp);
                existing[bytes] = '\0';
            }
        }
        fclose(fp);
    }

    fp = fopen(CUSTOM_RECIPES_FILE, "w");
    if (!fp) { free(existing); return; }

    if (existing && file_size > 2) {
        char *last_bracket = strrchr(existing, ']');
        if (last_bracket) *last_bracket = '\0';
        char *trimmed = existing;
        while (*trimmed == ' ' || *trimmed == '\n' || *trimmed == '\r') trimmed++;
        if (*trimmed == '[') trimmed++;
        char stripped[1048576];
        strncpy(stripped, trimmed, sizeof(stripped) - 1);
        stripped[sizeof(stripped) - 1] = '\0';
        int len = (int)strlen(stripped);
        while (len > 0 && (stripped[len-1] == ' ' || stripped[len-1] == '\n' || stripped[len-1] == '\r'))
            stripped[--len] = '\0';
        if (len > 0)
            fprintf(fp, "[\n%s,\n%s\n]\n", stripped, recipe_json);
        else
            fprintf(fp, "[\n%s\n]\n", recipe_json);
    } else {
        fprintf(fp, "[\n%s\n]\n", recipe_json);
    }

    fclose(fp);
    free(existing);
}

int load_custom_recipes(RecipeDB *db, int next_id)
{
    FILE *fp = fopen(CUSTOM_RECIPES_FILE, "r");
    if (!fp) return next_id;

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    rewind(fp);

    if (file_size <= 2 || file_size > 1048576) {
        fclose(fp);
        return next_id;
    }

    char *buffer = malloc((size_t)file_size + 1);
    if (!buffer) { fclose(fp); return next_id; }

    size_t bytes_read = fread(buffer, 1, (size_t)file_size, fp);
    buffer[bytes_read] = '\0';
    fclose(fp);

    char *pos = buffer;
    int added = 0;

    while (*pos && db->count < MAX_RECIPES) {
        char *obj_start = strchr(pos, '{');
        if (!obj_start) break;

        int depth = 0;
        char *obj_end = obj_start;
        while (*obj_end) {
            if (*obj_end == '{') depth++;
            else if (*obj_end == '}') {
                depth--;
                if (depth == 0) { obj_end++; break; }
            }
            obj_end++;
        }

        int obj_len = (int)(obj_end - obj_start);
        char *obj_buf = malloc((size_t)obj_len + 1);
        if (!obj_buf) break;
        strncpy(obj_buf, obj_start, (size_t)obj_len);
        obj_buf[obj_len] = '\0';

        Recipe r;
        memset(&r, 0, sizeof(Recipe));
        r.id = next_id++;
        r.default_servings = 2;

        json_get_string(obj_buf, "name", r.name, MAX_NAME_LEN);
        json_get_string(obj_buf, "description", r.description, MAX_STR_LEN);
        json_get_int(obj_buf, "prep_time_min", &r.prep_time_min);
        json_get_int(obj_buf, "cook_time_min", &r.cook_time_min);
        json_get_int(obj_buf, "default_servings", &r.default_servings);

        char diet_str[32], meal_str[32], cuisine_str[32];
        if (json_get_string(obj_buf, "diet", diet_str, 32)) {
            if (strcmp(diet_str, "non-veg") == 0) r.diet = NON_VEG;
            else if (strcmp(diet_str, "vegan") == 0)   r.diet = VEGAN;
            else                                        r.diet = VEG;
        }
        if (json_get_string(obj_buf, "meal", meal_str, 32)) {
            if (strcmp(meal_str, "breakfast") == 0)   r.meal = BREAKFAST;
            else if (strcmp(meal_str, "snack") == 0)  r.meal = SNACK;
            else if (strcmp(meal_str, "dessert") == 0) r.meal = DESSERT;
            else                                        r.meal = MAIN_COURSE;
        }
        if (json_get_string(obj_buf, "cuisine", cuisine_str, 32)) {
            if (strstr(cuisine_str, "South"))  r.cuisine = SOUTH_INDIAN;
            else if (strstr(cuisine_str, "East"))  r.cuisine = EAST_INDIAN;
            else if (strstr(cuisine_str, "West"))  r.cuisine = WEST_INDIAN;
            else if (strstr(cuisine_str, "Pan"))   r.cuisine = PAN_INDIAN;
            else                                    r.cuisine = NORTH_INDIAN;
        }

        if (strlen(r.name) > 0) {
            db->recipes[db->count++] = r;
            added++;
        }

        free(obj_buf);
        pos = obj_end;
    }

    free(buffer);
    return next_id;
}
