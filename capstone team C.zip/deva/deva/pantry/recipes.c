#include "recipes.h"
#include <string.h>

void add_recipe(RecipeDB *db, Recipe r)
{
    if (db->count < MAX_RECIPES) {
        db->recipes[db->count++] = r;
    }
}

static Ingredient make_ingredient(const char *name, const char *qty,
                                   int is_staple, int alias_count, ...)
{
    Ingredient ing;
    memset(&ing, 0, sizeof(Ingredient));
    strncpy(ing.name, name, MAX_NAME_LEN - 1);
    strncpy(ing.quantity, qty, MAX_QTY_LEN - 1);
    ing.is_staple   = is_staple;
    ing.alias_count = 0;
    (void)alias_count;
    return ing;
}

static void add_alias(Ingredient *ing, const char *alias)
{
    if (ing->alias_count < MAX_ALIASES) {
        strncpy(ing->aliases[ing->alias_count], alias, MAX_NAME_LEN - 1);
        ing->alias_count++;
    }
}

static Ingredient staple(const char *name, const char *qty)
{
    return make_ingredient(name, qty, 1, 0);
}

static Ingredient ing(const char *name, const char *qty)
{
    return make_ingredient(name, qty, 0, 0);
}

void init_recipe_db(RecipeDB *db)
{
    db->count = 0;

    Recipe r;
    Ingredient tmp;

    /* ── 1. Dal Tadka ──────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 1; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 30; r.default_servings = 2;
    strncpy(r.name, "Dal Tadka", MAX_NAME_LEN - 1);
    strncpy(r.description, "Creamy yellow lentils tempered with cumin, garlic and ghee. A beloved North Indian comfort dish served with rice or roti.", MAX_STR_LEN - 1);
    tmp = ing("toor dal", "1 cup"); add_alias(&tmp, "arhar dal"); add_alias(&tmp, "split pigeon peas"); add_alias(&tmp, "yellow lentils"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("garlic", "5 cloves, minced"); add_alias(&tmp, "lahsun"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1-inch piece, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, slit"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); add_alias(&tmp, "clarified butter"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); add_alias(&tmp, "haldi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); add_alias(&tmp, "lal mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); add_alias(&tmp, "namak"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rinse 1 cup toor dal thoroughly under cold water until the water runs clear. Soak it in 2 cups of water for 20 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Drain the soaked toor dal and add it to a pressure cooker with 2.5 cups fresh water, 1/2 teaspoon turmeric powder and 1 teaspoon salt. Pressure cook for 4 whistles on medium heat, then let the pressure release naturally for 10 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Mash the cooked dal gently with a spoon or potato masher until smooth and creamy. Add a splash of water if the dal is too thick and stir well.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Heat 2 tablespoons ghee in a heavy-bottomed pan over medium heat. Add 1 teaspoon cumin seeds and let them splutter and turn golden for about 30 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the finely chopped onion and saute for 5 to 6 minutes until the onion turns golden brown. Add the minced garlic and grated ginger and cook for 2 more minutes until the raw aroma disappears.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add the chopped tomatoes and 2 slit green chillies. Cook on medium heat for 6 to 7 minutes, pressing the tomatoes occasionally, until the ghee separates at the edges and the masala is thick.", MAX_STEP_LEN - 1);
    strncpy(r.steps[6], "Add 1 teaspoon red chilli powder and mix well for 30 seconds. Pour the mashed dal into this pan. Stir everything together and add water to adjust consistency. Simmer for 8 minutes on low heat.", MAX_STEP_LEN - 1);
    strncpy(r.steps[7], "For the final tadka, heat 1 teaspoon ghee in a small pan. Add a pinch of cumin seeds, 1 dried red chilli and a pinch of red chilli powder. As soon as it sizzles, pour this tadka directly over the dal and serve hot with rice or roti.", MAX_STEP_LEN - 1);
    r.step_count = 8;
    strncpy(r.tags[0], "comfort food", 63); strncpy(r.tags[1], "dal", 63); strncpy(r.tags[2], "lentils", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 2. Chana Masala ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 2; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 35; r.default_servings = 2;
    strncpy(r.name, "Chana Masala", MAX_NAME_LEN - 1);
    strncpy(r.description, "Spiced chickpeas in a tangy tomato-onion gravy. A protein-rich Punjabi classic served with bhature or rice.", MAX_STR_LEN - 1);
    tmp = ing("chickpeas", "1.5 cups, cooked or soaked overnight"); add_alias(&tmp, "chole"); add_alias(&tmp, "chana"); add_alias(&tmp, "kabuli chana"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 medium, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); add_alias(&tmp, "adrak lahsun paste"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("chana masala powder", "2 teaspoons"); add_alias(&tmp, "chole masala"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("amchur powder", "1 teaspoon"); add_alias(&tmp, "dry mango powder"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("bay leaf", "1 leaf"); add_alias(&tmp, "tej patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); add_alias(&tmp, "haldi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); add_alias(&tmp, "lal mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "If using dried chickpeas, soak 1 cup chickpeas overnight in plenty of water. Drain, rinse and pressure cook with 3 cups water and 1 teaspoon salt for 6 whistles until completely tender. Reserve the cooking liquid.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 3 tablespoons oil in a large pan. Add 1 teaspoon cumin seeds and 1 bay leaf. Let them splutter for 30 seconds over medium heat.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add the finely chopped onions and saute for 8 to 10 minutes on medium heat until they turn deep golden brown. This step is crucial for a rich gravy.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 1.5 tablespoons ginger-garlic paste and cook for 2 minutes until the raw smell disappears. Add the pureed tomatoes and cook for 8 minutes until oil surfaces on top.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add 1/2 teaspoon turmeric, 1 teaspoon red chilli powder, 2 teaspoons chana masala powder and 1 teaspoon amchur powder. Stir and cook the spice mixture for 2 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add the cooked chickpeas along with 1 cup of the reserved chickpea cooking liquid. Mix well, bring to a boil, then reduce heat and simmer for 15 minutes until the gravy thickens.", MAX_STEP_LEN - 1);
    strncpy(r.steps[6], "Sprinkle 1/2 teaspoon garam masala, adjust salt and stir. Garnish with freshly chopped coriander leaves and thin onion rings. Serve hot with bhature or steamed rice.", MAX_STEP_LEN - 1);
    r.step_count = 7;
    strncpy(r.tags[0], "protein", 63); strncpy(r.tags[1], "chickpeas", 63); strncpy(r.tags[2], "punjabi", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 3. Rajma Masala ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 3; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 40; r.default_servings = 2;
    strncpy(r.name, "Rajma Masala", MAX_NAME_LEN - 1);
    strncpy(r.description, "Red kidney beans slow-cooked in a thick, aromatic tomato-onion gravy. A Monday staple across North India, best paired with steamed rice.", MAX_STR_LEN - 1);
    tmp = ing("kidney beans", "1.5 cups soaked overnight"); add_alias(&tmp, "rajma"); add_alias(&tmp, "red kidney beans"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 medium, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("rajma masala powder", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "2 tablespoons, whisked"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1.5 teaspoons"); add_alias(&tmp, "dhaniya powder"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Soak 1.5 cups kidney beans in plenty of water overnight or for at least 8 hours. Drain, rinse well and pressure cook with 3 cups fresh water and 1 teaspoon salt for 7 to 8 whistles until the beans are completely soft and mashable. Reserve the cooked liquid.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 3 tablespoons oil in a heavy pan. Add 1 teaspoon cumin seeds and let them splutter. Add the finely chopped onions and cook on medium heat for 10 to 12 minutes until the onions turn a rich golden-brown.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add 2 tablespoons ginger-garlic paste and cook for 2 minutes. Add the chopped tomatoes, 1/2 teaspoon turmeric, 1 teaspoon red chilli powder and 1.5 teaspoons coriander powder. Cook for 10 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Lower the heat and add 2 tablespoons whisked curd while stirring continuously to prevent curdling. Cook for 2 minutes, then add 2 teaspoons rajma masala powder and stir well.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the cooked kidney beans along with 1.5 cups of the reserved bean broth. Stir, cover and simmer on low heat for 20 to 25 minutes, mashing a few beans against the pan to thicken the gravy naturally.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add 1/2 teaspoon garam masala, adjust salt and stir. Garnish with chopped coriander leaves and a small knob of butter on top. Serve hot with steamed basmati rice.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "kidney beans", 63); strncpy(r.tags[1], "comfort food", 63); strncpy(r.tags[2], "punjabi", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 4. Palak Paneer ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 4; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Palak Paneer", MAX_NAME_LEN - 1);
    strncpy(r.description, "Fresh cottage cheese cubes in a velvety, vibrant spinach sauce. A nutritious Punjabi dish that is as beautiful as it is delicious.", MAX_STR_LEN - 1);
    tmp = ing("spinach", "300g, fresh leaves"); add_alias(&tmp, "palak"); add_alias(&tmp, "baby spinach"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("paneer", "200g, cubed"); add_alias(&tmp, "cottage cheese"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1-inch piece"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("garlic", "4 cloves"); add_alias(&tmp, "lahsun"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2 pieces"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh cream", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Bring a large pot of water to a rolling boil. Add 300g fresh spinach leaves and blanch for exactly 2 minutes until wilted but still bright green. Immediately drain and plunge into a bowl of ice-cold water to stop cooking and preserve the colour.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Drain the cooled spinach and blend it in a blender with 2 green chillies and 2 tablespoons of water into a smooth, thick puree. Set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 1 tablespoon ghee in a pan over medium heat. Lightly pan-fry 200g paneer cubes for 2 minutes per side until golden. Remove and set aside on a plate.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "In the same pan, heat 1 more tablespoon ghee. Add 1 teaspoon cumin seeds and let them splutter. Add the chopped onion, minced garlic and grated ginger and saute for 6 to 7 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the chopped tomatoes, 1/4 teaspoon turmeric and 1 teaspoon salt. Cook for 7 minutes until the tomatoes are completely broken down and the masala is thick and oily at the edges.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add the spinach puree and mix well. Simmer for 5 minutes, stirring occasionally. Add a splash of water if the gravy is too thick.", MAX_STEP_LEN - 1);
    strncpy(r.steps[6], "Add the pan-fried paneer cubes and 2 tablespoons fresh cream. Sprinkle 1/2 teaspoon garam masala. Stir gently and simmer for 3 more minutes. Serve hot with roti, paratha or steamed rice.", MAX_STEP_LEN - 1);
    r.step_count = 7;
    strncpy(r.tags[0], "paneer", 63); strncpy(r.tags[1], "spinach", 63); strncpy(r.tags[2], "iron-rich", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 5. Paneer Butter Masala ───────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 5; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 30; r.default_servings = 2;
    strncpy(r.name, "Paneer Butter Masala", MAX_NAME_LEN - 1);
    strncpy(r.description, "Soft paneer cubes in a rich, creamy tomato-cashew gravy. The restaurant favourite that everyone loves.", MAX_STR_LEN - 1);
    tmp = ing("paneer", "250g, cubed"); add_alias(&tmp, "cottage cheese"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "4 large, roughly chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, roughly chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashews", "15 pieces"); add_alias(&tmp, "kaju"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh cream", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("butter", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("sugar", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("kasuri methi", "1 teaspoon"); add_alias(&tmp, "dried fenugreek leaves"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "In a pan, heat 1 tablespoon butter. Add the roughly chopped onion, tomatoes and 15 cashews. Cook over medium heat for 10 minutes until everything is soft and the tomatoes break down completely.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Let the tomato-onion-cashew mixture cool slightly, then blend it into a completely smooth puree using a blender. Pass through a fine sieve or strainer, pressing firmly to get a silky smooth sauce. Discard the solids.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "In the same pan, heat 2 tablespoons butter over medium heat. Add 1.5 tablespoons ginger-garlic paste and cook for 1 minute until fragrant.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add the strained tomato-cashew puree. Add 1/4 teaspoon turmeric, 1 teaspoon red chilli powder and 1 teaspoon salt. Stir well and cook over medium-low heat for 10 minutes until the gravy darkens and thickens.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the paneer cubes and 1 teaspoon sugar. Mix gently and simmer for 5 minutes so the paneer absorbs the flavours.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add 3 tablespoons fresh cream and 1/2 teaspoon garam masala. Crush 1 teaspoon kasuri methi between your palms and add it to the gravy. Stir gently, simmer for 2 minutes and serve hot with naan or butter roti.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "paneer", 63); strncpy(r.tags[1], "restaurant style", 63); strncpy(r.tags[2], "creamy", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 6. Aloo Gobi ──────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 6; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Aloo Gobi", MAX_NAME_LEN - 1);
    strncpy(r.description, "Potatoes and cauliflower stir-fried with cumin and aromatic spices. A simple, hearty dry sabzi loved across North India.", MAX_STR_LEN - 1);
    tmp = ing("potato", "2 large, cubed"); add_alias(&tmp, "aloo"); add_alias(&tmp, "batata"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cauliflower", "1 small head, cut into florets"); add_alias(&tmp, "gobi"); add_alias(&tmp, "phool gobi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "1 large, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1-inch piece, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2 pieces, chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "3/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Peel and cube 2 large potatoes into 1-inch pieces. Cut 1 small cauliflower head into medium florets. Keep both in separate bowls.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 3 tablespoons oil in a wide pan or kadai over medium-high heat. Add 1 teaspoon cumin seeds and let them turn golden and aromatic, about 30 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add the potato cubes to the hot oil. Stir well to coat with oil and cumin. Sprinkle 1/4 teaspoon turmeric and a pinch of salt. Cook uncovered on medium heat for 7 to 8 minutes, turning occasionally, until the potatoes are half cooked and golden at the edges.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add the cauliflower florets, grated ginger, 2 chopped green chillies and the remaining 1/4 teaspoon turmeric. Mix well, cover the pan and cook on low heat for 8 minutes until both vegetables are almost tender.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the chopped tomato, 3/4 teaspoon red chilli powder, 1.5 teaspoons coriander powder and 1 teaspoon salt. Mix gently, then cook uncovered on medium heat for 5 more minutes until the tomato breaks down and coats the vegetables.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Sprinkle 1/4 teaspoon garam masala, mix gently one final time and check that potatoes and cauliflower are fully tender. Garnish with freshly chopped coriander leaves and serve with hot phulka roti.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "potato", 63); strncpy(r.tags[1], "cauliflower", 63); strncpy(r.tags[2], "dry sabzi", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 7. Aloo Matar ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 7; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Aloo Matar", MAX_NAME_LEN - 1);
    strncpy(r.description, "Potatoes and green peas in a light tomato-onion gravy. A quick and comforting everyday sabzi.", MAX_STR_LEN - 1);
    tmp = ing("potato", "3 medium, cubed"); add_alias(&tmp, "aloo"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green peas", "1 cup, fresh or frozen"); add_alias(&tmp, "matar"); add_alias(&tmp, "mattar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "3/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat 2 tablespoons oil in a kadai. Add 1 teaspoon cumin seeds and let them splutter. Add the chopped onion and saute for 5 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add 1 tablespoon ginger-garlic paste and cook for 1 minute. Add the chopped tomatoes, 1/2 teaspoon turmeric, 3/4 teaspoon red chilli powder and 1 teaspoon coriander powder. Cook for 7 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add the cubed potatoes and mix well to coat with masala. Add 1/2 cup water and 1 teaspoon salt. Cover and cook on medium-low heat for 10 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 1 cup green peas, stir, cover and cook for another 7 to 8 minutes until potatoes are completely cooked through and peas are tender.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Sprinkle 1/4 teaspoon garam masala, adjust salt and garnish with coriander leaves. Serve with roti or rice.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "potato", 63); strncpy(r.tags[1], "peas", 63); strncpy(r.tags[2], "quick", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 8. Matar Paneer ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 8; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Matar Paneer", MAX_NAME_LEN - 1);
    strncpy(r.description, "Green peas and cottage cheese cubes in a spiced tomato gravy. A crowd-pleasing classic.", MAX_STR_LEN - 1);
    tmp = ing("paneer", "200g, cubed"); add_alias(&tmp, "cottage cheese"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green peas", "1 cup"); add_alias(&tmp, "matar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 large, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh cream", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat 3 tablespoons oil. Add 1 teaspoon cumin seeds, let splutter. Add onion and cook 7 minutes until golden brown.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add ginger-garlic paste and cook 2 minutes. Add tomato puree, turmeric, red chilli powder and coriander powder. Cook 8 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add green peas and 1/2 cup water. Cover and cook for 5 minutes until peas are half tender.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add paneer cubes gently and mix. Simmer for 5 minutes. Add fresh cream and garam masala, stir and serve hot.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "paneer", 63); strncpy(r.tags[1], "peas", 63); r.tag_count = 2;
    add_recipe(db, r);

    /* ── 9. Jeera Rice ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 9; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Jeera Rice", MAX_NAME_LEN - 1);
    strncpy(r.description, "Fluffy basmati rice tempered with cumin seeds and ghee. The perfect accompaniment to any dal or curry.", MAX_STR_LEN - 1);
    tmp = ing("basmati rice", "1 cup"); add_alias(&tmp, "long-grain rice"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1.5 teaspoons"); add_alias(&tmp, "jeera"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("bay leaf", "1 leaf"); add_alias(&tmp, "tej patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rinse 1 cup basmati rice under cold water 3 to 4 times until the water runs clear. Soak in 1 cup fresh water for 20 minutes, then drain.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons ghee in a heavy-bottomed pot over medium heat. Add 1.5 teaspoons cumin seeds and 1 bay leaf. Let the cumin seeds sizzle and turn golden, about 30 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add the drained basmati rice and gently stir to coat each grain with the ghee and cumin for 1 minute.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 1.75 cups hot water and 1 teaspoon salt. Bring to a boil, then reduce heat to the lowest setting, cover tightly and cook for 15 minutes without lifting the lid.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Turn off heat and let the rice rest covered for 5 minutes. Fluff gently with a fork and serve.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "rice", 63); strncpy(r.tags[1], "quick", 63); strncpy(r.tags[2], "sides", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 10. Lemon Rice ────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 10; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 10; r.default_servings = 2;
    strncpy(r.name, "Lemon Rice", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tangy South Indian rice tempered with mustard seeds, curry leaves, peanuts and fresh lemon juice. Quick and bright in flavour.", MAX_STR_LEN - 1);
    tmp = ing("cooked rice", "2 cups, cooled"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("lemon juice", "3 tablespoons, freshly squeezed"); add_alias(&tmp, "nimbu"); add_alias(&tmp, "lime juice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("peanuts", "3 tablespoons, roasted"); add_alias(&tmp, "groundnuts"); add_alias(&tmp, "moongphali"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 to 12 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); add_alias(&tmp, "sukhi lal mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); add_alias(&tmp, "sarson"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("urad dal", "1 teaspoon"); add_alias(&tmp, "split black lentils"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Ensure the cooked rice is cooled completely and the grains are separated. Spread on a plate if needed.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons oil in a wide pan over medium heat. Add 1 teaspoon mustard seeds. When they splutter and pop, add 1 teaspoon urad dal and stir for 30 seconds until the dal turns light golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add 2 dried red chillies (broken in half) and 10 to 12 fresh curry leaves. Stir for 20 seconds being careful of splattering.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 3 tablespoons roasted peanuts and stir for 1 minute. Add 1/2 teaspoon turmeric powder and mix quickly.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the cooled rice and 1 teaspoon salt. Gently mix to coat the rice evenly with the tempering, being careful not to break the grains.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Turn off the heat and add 3 tablespoons freshly squeezed lemon juice. Mix gently, taste and adjust salt and lemon. Serve at room temperature or warm.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "rice", 63); strncpy(r.tags[1], "south indian", 63); strncpy(r.tags[2], "tangy", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 11. Curd Rice ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 11; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 5; r.default_servings = 2;
    strncpy(r.name, "Curd Rice", MAX_NAME_LEN - 1);
    strncpy(r.description, "Soft, creamy rice mixed with fresh curd and tempered with mustard seeds and curry leaves. The ultimate comfort food of South India.", MAX_STR_LEN - 1);
    tmp = ing("cooked rice", "2 cups, slightly overcooked"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "1.5 cups, fresh"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("milk", "1/4 cup"); add_alias(&tmp, "doodh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1/2 inch, finely grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "1 piece, finely chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "8 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1/2 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("urad dal", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "3/4 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Mash 2 cups cooked rice gently with the back of a spoon until slightly sticky. Add 1/4 cup warm milk and mix well.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Whisk 1.5 cups fresh curd until smooth. Pour the whisked curd into the mashed rice. Add 3/4 teaspoon salt and mix thoroughly.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 1 tablespoon oil in a small pan. Add 1/2 teaspoon mustard seeds and wait for them to splutter. Add 1/2 teaspoon urad dal and stir for 20 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 8 fresh curry leaves and 1 chopped green chilli. Stir for 15 seconds, then pour this hot tempering directly over the curd rice.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the finely grated ginger, mix gently and serve immediately or refrigerate for 30 minutes for a chilled version. Serve with pickle and papad.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "curd", 63); strncpy(r.tags[1], "south indian", 63); strncpy(r.tags[2], "cooling", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 12. Vegetable Biryani ─────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 12; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 40; r.default_servings = 2;
    strncpy(r.name, "Vegetable Biryani", MAX_NAME_LEN - 1);
    strncpy(r.description, "Fragrant basmati rice layered with spiced vegetables and cooked dum-style. A festive one-pot meal.", MAX_STR_LEN - 1);
    tmp = ing("basmati rice", "1.5 cups"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mixed vegetables", "2 cups (carrot, beans, peas, potato)"); add_alias(&tmp, "sabzi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, thinly sliced"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "1/2 cup, whisked"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mint leaves", "1/4 cup"); add_alias(&tmp, "pudina"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("biryani masala", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("saffron strands", "a pinch, soaked in 2 tablespoons warm milk"); add_alias(&tmp, "kesar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rinse and soak basmati rice in cold water for 30 minutes. Par-boil rice in salted boiling water for 7 minutes until 70 percent cooked. Drain and set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons ghee in a wide pot. Fry the sliced onions until deep golden and crispy, about 12 minutes. Remove half and set aside for garnish.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "In the same pot with remaining onions, add ginger-garlic paste and cook 2 minutes. Add mixed vegetables, curd, biryani masala, garam masala and salt. Cook 8 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Layer the par-boiled rice evenly over the vegetables. Drizzle saffron milk, remaining 1 tablespoon ghee and mint leaves on top.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Seal the pot tightly with foil or a tight lid. Cook on high heat for 2 minutes then on the lowest heat for 20 minutes (dum cooking). Let rest 5 minutes before opening.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Gently mix the layers before serving. Garnish with reserved fried onions. Serve with raita and papad.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "biryani", 63); strncpy(r.tags[1], "festive", 63); strncpy(r.tags[2], "rice", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 13. Sambar ────────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 13; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 35; r.default_servings = 2;
    strncpy(r.name, "Sambar", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tangy tamarind and lentil stew packed with vegetables and tempered with South Indian spices. Served with idli, dosa or rice.", MAX_STR_LEN - 1);
    tmp = ing("toor dal", "1/2 cup"); add_alias(&tmp, "arhar dal"); add_alias(&tmp, "split pigeon peas"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("drumstick", "1, cut into 3-inch pieces"); add_alias(&tmp, "murungakkai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("small onion", "10 to 12, peeled"); add_alias(&tmp, "shallots"); add_alias(&tmp, "sambar onion"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, quartered"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tamarind", "1 small lemon-sized ball"); add_alias(&tmp, "imli"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("sambar powder", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "12 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Pressure cook 1/2 cup toor dal with 1.5 cups water and 1/4 teaspoon turmeric for 4 whistles. Mash the cooked dal until smooth and set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Soak the tamarind in 1 cup warm water for 15 minutes. Squeeze and strain to extract a thick tamarind juice. Discard the pulp.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 2 tablespoons oil in a large pot. Add 1 teaspoon mustard seeds and 2 dried red chillies. When the mustard seeds splutter, add the shallots and curry leaves. Saute for 4 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add the drumstick pieces and tomato quarters. Add 2 tablespoons sambar powder, 1/4 teaspoon turmeric and 1.5 teaspoons salt. Add tamarind water. Bring to a boil and cook for 10 minutes until drumstick is tender.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the mashed toor dal and 1 more cup of water. Stir well, bring to a boil and simmer for 10 minutes until the sambar thickens to your desired consistency. Serve with rice, idli or dosa.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "south indian", 63); strncpy(r.tags[1], "dal", 63); strncpy(r.tags[2], "tamarind", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 14. Rasam ─────────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 14; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Tomato Rasam", MAX_NAME_LEN - 1);
    strncpy(r.description, "A light, peppery, tamarind-tomato South Indian soup that is both digestive and deeply comforting.", MAX_STR_LEN - 1);
    tmp = ing("tomato", "3 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tamarind extract", "2 tablespoons"); add_alias(&tmp, "imli"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("rasam powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cooked toor dal", "1/4 cup, mashed"); add_alias(&tmp, "dal"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("garlic", "3 cloves, crushed"); add_alias(&tmp, "lahsun"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Blend 3 chopped tomatoes into a smooth puree. Heat 1 tablespoon oil in a pot. Add 1 teaspoon mustard seeds, 2 dry red chillies and 10 curry leaves. Stir for 30 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add crushed garlic and stir for 1 minute. Add the tomato puree, tamarind extract, rasam powder, turmeric and salt. Add 2 cups water.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Bring to a boil, then add mashed toor dal. Simmer for 10 minutes until rasam is thin and aromatic. Serve hot with rice.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "south indian", 63); strncpy(r.tags[1], "soup", 63); strncpy(r.tags[2], "light", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 15. Poha ──────────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 15; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = WEST_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 15; r.default_servings = 2;
    strncpy(r.name, "Poha", MAX_NAME_LEN - 1);
    strncpy(r.description, "Light and fluffy flattened rice tempered with mustard seeds, curry leaves, peanuts and onion. Maharashtra's favourite breakfast.", MAX_STR_LEN - 1);
    tmp = ing("flattened rice", "2 cups"); add_alias(&tmp, "poha"); add_alias(&tmp, "beaten rice"); add_alias(&tmp, "chivda"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("potato", "1 small, diced small"); add_alias(&tmp, "aloo"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("peanuts", "2 tablespoons"); add_alias(&tmp, "groundnuts"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, slit"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("lemon juice", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("sugar", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "3/4 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Place the flattened rice in a strainer and rinse under cold water for 10 seconds. Drain and let it sit for 5 minutes to soften evenly. The poha should be just soft, not mushy.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons oil in a wide pan. Add 2 tablespoons peanuts and roast for 2 minutes until golden. Remove and set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "In the same oil, add 1 teaspoon mustard seeds. When they pop, add 2 slit green chillies and 10 curry leaves. Stir for 20 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add the diced potato and cook for 5 minutes until golden. Add the chopped onion and saute for 3 more minutes until translucent.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add 1/2 teaspoon turmeric and the rinsed flattened rice. Add 3/4 teaspoon salt and 1 teaspoon sugar. Gently mix everything together without breaking the poha.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Cook covered on low heat for 2 minutes. Add the roasted peanuts and 1 tablespoon lemon juice. Mix gently and serve warm with a cup of hot chai.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "breakfast", 63); strncpy(r.tags[1], "maharashtrian", 63); strncpy(r.tags[2], "light", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 16. Upma ──────────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 16; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Upma", MAX_NAME_LEN - 1);
    strncpy(r.description, "Savoury semolina porridge tempered with mustard seeds, ginger and curry leaves. A South Indian breakfast staple.", MAX_STR_LEN - 1);
    tmp = ing("semolina", "1 cup"); add_alias(&tmp, "rava"); add_alias(&tmp, "suji"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, finely chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1/2 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashews", "10 pieces"); add_alias(&tmp, "kaju"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("urad dal", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Dry roast 1 cup semolina in a pan over medium heat for 4 to 5 minutes, stirring constantly, until it turns light golden and aromatic. Set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "In the same pan, heat 2 tablespoons oil. Add 1 teaspoon mustard seeds and 1 teaspoon urad dal. When they splutter and the dal turns golden, add 10 cashews and roast for 1 minute.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add 10 curry leaves, 2 chopped green chillies and grated ginger. Stir for 30 seconds. Add chopped onion and saute for 4 minutes until translucent.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 2.5 cups water and 1 teaspoon salt. Bring to a full boil.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Reduce heat to low and slowly add the roasted semolina while stirring continuously with the other hand to prevent lumps from forming.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Cover and cook on the lowest heat for 3 to 4 minutes until the upma is firm and cooked through. Serve hot with coconut chutney.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "breakfast", 63); strncpy(r.tags[1], "semolina", 63); strncpy(r.tags[2], "south indian", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 17. Masala Dosa Filling ────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 17; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Masala Dosa", MAX_NAME_LEN - 1);
    strncpy(r.description, "Crispy fermented rice crepe filled with spiced potato masala. South India's most iconic breakfast.", MAX_STR_LEN - 1);
    tmp = ing("dosa batter", "2 cups, ready-made or homemade"); add_alias(&tmp, "rice batter"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("potato", "3 medium, boiled and mashed"); add_alias(&tmp, "aloo"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, sliced thin"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, slit"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1/2 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("urad dal", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("chana dal", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Make the aloo masala filling: Heat 2 tablespoons oil in a pan. Add 1 teaspoon mustard seeds. When they pop, add 1 teaspoon urad dal and 1 teaspoon chana dal and stir until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add 10 curry leaves, 2 slit green chillies and grated ginger. Stir for 30 seconds. Add sliced onion and cook for 5 minutes until soft.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add 1/2 teaspoon turmeric powder and the mashed potatoes. Add 1 teaspoon salt and mix well, cooking for 3 minutes. The filling should be slightly dry.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "To make the dosa: Heat a flat cast iron griddle or non-stick pan over high heat. Pour a ladleful of batter in the centre and spread in concentric circles to make a thin crepe.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Drizzle 1/2 teaspoon oil around the edges. Cook until the bottom is golden and crisp and the edges lift, about 2 to 3 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Place 2 tablespoons of the aloo masala filling in the centre of the dosa, fold in half and serve immediately with sambar and coconut chutney.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "dosa", 63); strncpy(r.tags[1], "breakfast", 63); strncpy(r.tags[2], "south indian", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 18. Pongal ────────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 18; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Khichdi Pongal", MAX_NAME_LEN - 1);
    strncpy(r.description, "Soft, comforting rice and lentil porridge with black pepper and ghee. Tamil Nadu's beloved breakfast dish.", MAX_STR_LEN - 1);
    tmp = ing("rice", "1 cup"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("moong dal", "1/3 cup"); add_alias(&tmp, "split yellow lentils"); add_alias(&tmp, "yellow moong"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashews", "10 pieces"); add_alias(&tmp, "kaju"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1-inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("black pepper", "1 teaspoon, coarsely crushed"); add_alias(&tmp, "kali mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "12 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Dry roast 1/3 cup moong dal in a pan for 3 minutes until lightly golden. Rinse and add to 1 cup rice. Wash together and pressure cook with 4 cups water and 1.5 teaspoons salt for 5 whistles until very soft and mushy.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons ghee in a pan. Add 10 cashews and roast until golden. Add 1 teaspoon cumin seeds, 1 teaspoon crushed black pepper, grated ginger and curry leaves. Stir for 1 minute.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Pour this tempering over the cooked rice-dal mixture. Mix gently until everything is combined and the pongal is creamy. Serve hot with sambar and coconut chutney.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "breakfast", 63); strncpy(r.tags[1], "comfort food", 63); strncpy(r.tags[2], "south indian", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 19. Egg Bhurji ────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 19; r.diet = NON_VEG; r.meal = BREAKFAST; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 10; r.default_servings = 2;
    strncpy(r.name, "Egg Bhurji", MAX_NAME_LEN - 1);
    strncpy(r.description, "Spiced Indian scrambled eggs with onion, tomato and green chilli. Quick, protein-rich and absolutely delicious.", MAX_STR_LEN - 1);
    tmp = ing("eggs", "4 large"); add_alias(&tmp, "anda"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "1 medium, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, finely chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1/2 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "3/4 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Beat 4 eggs in a bowl with a pinch of salt until the whites and yolks are fully combined.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons oil in a non-stick pan. Add chopped onion and cook for 4 minutes until soft. Add grated ginger and 2 chopped green chillies and cook for 1 minute.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add chopped tomato, 1/4 teaspoon turmeric and 1/2 teaspoon red chilli powder. Cook for 3 minutes until tomatoes soften.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Pour the beaten eggs into the pan. Let them set slightly for 15 seconds then start stirring continuously on medium-low heat to create soft, fluffy curds of egg. Add salt and 1/4 teaspoon garam masala. Serve with pav or roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "eggs", 63); strncpy(r.tags[1], "quick", 63); strncpy(r.tags[2], "protein", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 20. Egg Curry ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 20; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Egg Curry", MAX_NAME_LEN - 1);
    strncpy(r.description, "Hard-boiled eggs in a rich, spiced onion-tomato gravy. A quick and satisfying protein-packed curry.", MAX_STR_LEN - 1);
    tmp = ing("eggs", "4 large, hard boiled and peeled"); add_alias(&tmp, "anda"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 large, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "2 tablespoons, whisked"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Score 4 hard-boiled peeled eggs with shallow cuts to help them absorb the gravy. Optionally, pan-fry in 1 teaspoon oil with a pinch of turmeric for 2 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 3 tablespoons oil. Add 1 teaspoon cumin seeds. Add chopped onion and cook on medium heat for 8 minutes until deep golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add ginger-garlic paste and cook 2 minutes. Add tomato puree, turmeric, red chilli powder and coriander powder. Cook 8 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add whisked curd on low heat, stirring quickly to prevent curdling. Cook 2 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add 1 cup water and the eggs. Simmer 8 minutes. Add garam masala, adjust salt and serve with rice or roti.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "eggs", 63); strncpy(r.tags[1], "protein", 63); strncpy(r.tags[2], "quick", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 21. Chicken Curry ─────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 21; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 40; r.default_servings = 2;
    strncpy(r.name, "Chicken Curry", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tender chicken pieces in a bold, aromatic onion-tomato-spice gravy. The definitive Indian chicken curry.", MAX_STR_LEN - 1);
    tmp = ing("chicken", "500g, curry cut with bone"); add_alias(&tmp, "murgh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 large, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "3 tablespoons, whisked"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("whole spices", "1 bay leaf, 2 cardamom, 1-inch cinnamon, 4 cloves"); add_alias(&tmp, "sabut masala"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "4 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Marinate 500g chicken pieces with 1 tablespoon ginger-garlic paste, 1/4 teaspoon turmeric, 1/2 teaspoon red chilli powder and 1/2 teaspoon salt for 30 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 4 tablespoons oil in a heavy pot. Add whole spices (bay leaf, cardamom, cinnamon, cloves) and let them sizzle for 1 minute until fragrant.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add finely chopped onion and cook on medium heat for 12 minutes until deep golden brown. This is the base of the curry and must not be rushed.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 1 tablespoon ginger-garlic paste and cook for 2 minutes. Add chopped tomatoes and cook for 8 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add remaining turmeric, red chilli powder, coriander powder and salt. Stir well. Add marinated chicken pieces and cook on high heat for 5 minutes, browning the chicken on all sides.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add whisked curd on low heat, stirring quickly. Add 1 cup warm water, cover and cook for 20 minutes on medium-low heat until chicken is fully cooked and tender.", MAX_STEP_LEN - 1);
    strncpy(r.steps[6], "Sprinkle 1 teaspoon garam masala and simmer uncovered for 5 minutes to thicken the gravy. Garnish with coriander and serve with rice or naan.", MAX_STEP_LEN - 1);
    r.step_count = 7;
    strncpy(r.tags[0], "chicken", 63); strncpy(r.tags[1], "non-veg", 63); strncpy(r.tags[2], "curry", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 22. Chicken Biryani ───────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 22; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 30; r.cook_time_min = 50; r.default_servings = 2;
    strncpy(r.name, "Chicken Biryani", MAX_NAME_LEN - 1);
    strncpy(r.description, "Aromatic layered rice dish with marinated spiced chicken, fried onions and saffron. India's most beloved celebration meal.", MAX_STR_LEN - 1);
    tmp = ing("chicken", "500g, curry cut"); add_alias(&tmp, "murgh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("basmati rice", "1.5 cups"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "1/2 cup, whisked"); add_alias(&tmp, "yogurt"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, thinly sliced"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mint leaves", "1/3 cup"); add_alias(&tmp, "pudina"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("biryani masala", "2.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("saffron", "a pinch soaked in 3 tablespoons warm milk"); add_alias(&tmp, "kesar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Marinate chicken: Mix 500g chicken with curd, ginger-garlic paste, biryani masala, red chilli powder, garam masala and 1 teaspoon salt. Marinate for at least 1 hour or overnight in the refrigerator.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Rinse and soak basmati rice for 30 minutes. Par-boil in salted water (1 teaspoon salt per litre) with whole spices for 7 minutes until 70 percent cooked. Drain.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 2 tablespoons ghee in a heavy pot. Fry sliced onions for 15 minutes until deep golden and crispy. Remove half for garnish.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add marinated chicken to the pot with remaining onions. Cook on high heat for 8 minutes, turning often. The chicken should be half cooked.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Layer the par-boiled rice over the chicken. Scatter mint leaves, drizzle saffron milk and 1 tablespoon ghee over the rice. Top with crispy fried onions.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Seal pot tightly with foil then the lid. Cook on high heat 3 minutes, then on the lowest heat for 25 minutes. Rest 10 minutes before opening and gently mixing.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "biryani", 63); strncpy(r.tags[1], "chicken", 63); strncpy(r.tags[2], "festive", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 23. Butter Chicken ────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 23; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 35; r.default_servings = 2;
    strncpy(r.name, "Butter Chicken", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tender tandoor-style chicken in a velvety, mildly spiced tomato-cream-butter sauce. India's most popular dish worldwide.", MAX_STR_LEN - 1);
    tmp = ing("chicken", "400g boneless, cubed"); add_alias(&tmp, "murgh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "4 large, roughly chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("butter", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh cream", "4 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashews", "15 pieces"); add_alias(&tmp, "kaju"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "3 tablespoons for marination"); add_alias(&tmp, "yogurt"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("kasuri methi", "1 teaspoon, dried fenugreek leaves"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("sugar", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Marinate chicken: Mix 400g boneless chicken cubes with 3 tablespoons curd, ginger-garlic paste, 1 teaspoon red chilli powder, 1/2 teaspoon garam masala and 1/2 teaspoon salt. Marinate for 1 to 2 hours.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Cook marinated chicken in 1 tablespoon butter in a hot pan for 8 to 10 minutes until charred at edges and fully cooked. Set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "In the same pan, melt 2 tablespoons butter. Cook roughly chopped tomatoes and 15 cashews with 1/2 teaspoon red chilli powder for 10 minutes. Blend smooth, then strain.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Return strained sauce to the pan. Simmer for 5 minutes. Add 1 teaspoon sugar and 1/2 teaspoon salt. Add the cooked chicken pieces.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add 4 tablespoons fresh cream, 1/2 teaspoon garam masala and 1 teaspoon crushed kasuri methi. Simmer for 5 minutes. Serve with naan or butter rice.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "chicken", 63); strncpy(r.tags[1], "restaurant style", 63); strncpy(r.tags[2], "creamy", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 24. Fish Curry ────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 24; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Fish Curry", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tangy coconut-based South Indian fish curry with tamarind and curry leaves. Perfectly pairs with steamed rice.", MAX_STR_LEN - 1);
    tmp = ing("fish", "400g, firm white fish (rohu, pomfret or kingfish), cut into chunks"); add_alias(&tmp, "macchi"); add_alias(&tmp, "meen"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("coconut milk", "1 cup"); add_alias(&tmp, "nariyal ka doodh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tamarind paste", "1 tablespoon"); add_alias(&tmp, "imli"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "12 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rub fish pieces with 1/4 teaspoon turmeric and 1/2 teaspoon salt. Set aside for 10 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 3 tablespoons oil. Add mustard seeds, let splutter. Add curry leaves and chopped onion. Cook 6 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add ginger-garlic paste and cook 2 minutes. Add tomatoes, remaining turmeric, red chilli powder and coriander powder. Cook 7 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add tamarind paste and coconut milk. Stir gently and bring to a simmer. Add fish pieces carefully.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Simmer on medium-low heat for 10 minutes without stirring much. The fish should be cooked through and flake easily. Serve with steamed rice.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "fish", 63); strncpy(r.tags[1], "south indian", 63); strncpy(r.tags[2], "coconut", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 25. Prawn Masala ──────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 25; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Prawn Masala", MAX_NAME_LEN - 1);
    strncpy(r.description, "Juicy prawns cooked in a fiery, aromatic onion-tomato masala. Quick, bold and deeply satisfying.", MAX_STR_LEN - 1);
    tmp = ing("prawns", "300g, cleaned and deveined"); add_alias(&tmp, "jhinga"); add_alias(&tmp, "shrimp"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 large, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Marinate cleaned prawns with 1/4 teaspoon turmeric and 1/4 teaspoon salt for 10 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat oil, add mustard seeds, let splutter. Add curry leaves, then onion. Cook 8 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add ginger-garlic paste, cook 2 minutes. Add tomatoes, spices and salt. Cook 8 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add marinated prawns. Cook on high heat for 4 to 5 minutes, stirring, until prawns turn pink and curl. Do not overcook. Serve hot with rice.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "prawns", 63); strncpy(r.tags[1], "seafood", 63); strncpy(r.tags[2], "quick", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 26. Mutton Curry ──────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 26; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 60; r.default_servings = 2;
    strncpy(r.name, "Mutton Curry", MAX_NAME_LEN - 1);
    strncpy(r.description, "Slow-cooked mutton in a bold, complex spice gravy. Rich, hearty and worth every minute of cooking time.", MAX_STR_LEN - 1);
    tmp = ing("mutton", "500g, bone-in curry cut"); add_alias(&tmp, "lamb"); add_alias(&tmp, "gosht"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 large, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "1/2 cup, whisked"); add_alias(&tmp, "yogurt"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("whole spices", "2 bay leaves, 3 cardamom, 1 cinnamon, 5 cloves, 1 star anise"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "4 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "2 teaspoons or to taste"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Marinate mutton with curd, ginger-garlic paste, turmeric, red chilli powder and salt for 2 hours or overnight.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 4 tablespoons oil in a pressure cooker. Add whole spices and sizzle 1 minute. Add onion and cook 15 minutes until very dark golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add ginger-garlic paste residue from marinade and cook 2 minutes. Add tomatoes, coriander powder and cook 8 minutes until masala is thick.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add marinated mutton. Cook on high heat 8 minutes, browning the mutton well. Add 1.5 cups water, pressure cook for 6 to 7 whistles.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Let pressure release naturally. Open, add garam masala and simmer for 10 minutes to reduce gravy. Serve with rice or roti.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "mutton", 63); strncpy(r.tags[1], "slow cooked", 63); strncpy(r.tags[2], "festive", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 27. Keema Matar ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 27; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 30; r.default_servings = 2;
    strncpy(r.name, "Keema Matar", MAX_NAME_LEN - 1);
    strncpy(r.description, "Spiced minced meat with green peas in a rich, dry masala. A classic Mughlai-style dish.", MAX_STR_LEN - 1);
    tmp = ing("minced meat", "400g (mutton or chicken keema)"); add_alias(&tmp, "keema"); add_alias(&tmp, "ground meat"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green peas", "1 cup"); add_alias(&tmp, "matar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat 3 tablespoons oil. Add cumin seeds, let splutter. Add onion and cook 8 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add ginger-garlic paste, cook 2 minutes. Add tomatoes with all spices and salt. Cook 8 minutes until oil separates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add minced meat and break into small pieces as it cooks. Cook on high heat for 10 minutes, stirring often, until all moisture evaporates.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add green peas and 1/2 cup water. Cover and cook 10 minutes. Finish with garam masala and serve with roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "keema", 63); strncpy(r.tags[1], "minced meat", 63); strncpy(r.tags[2], "mughlai", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 28. Bhindi Masala ─────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 28; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Bhindi Masala", MAX_NAME_LEN - 1);
    strncpy(r.description, "Crispy okra in a spiced onion-tomato masala. The key to non-slimy bhindi is high heat and no water.", MAX_STR_LEN - 1);
    tmp = ing("okra", "300g, washed, dried and cut"); add_alias(&tmp, "bhindi"); add_alias(&tmp, "lady's finger"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1/2 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("amchur powder", "1/2 teaspoon"); add_alias(&tmp, "dry mango powder"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "3/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Wash okra thoroughly, then pat completely dry with a cloth. Cut into 1-inch rounds. Moisture causes sliminess, so ensure they are bone dry.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat 2 tablespoons oil in a wide pan over high heat. Spread okra in a single layer. Stir-fry on high heat for 8 minutes without covering until crispy and lightly browned. Remove and set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "In the same pan, heat 1 tablespoon oil. Add cumin seeds, let splutter. Add onion and ginger and cook for 5 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add tomatoes, turmeric, red chilli powder, coriander powder and salt. Cook 5 minutes. Add crispy okra back, add amchur powder and toss gently for 2 minutes. Serve with roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "okra", 63); strncpy(r.tags[1], "dry sabzi", 63); strncpy(r.tags[2], "crispy", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 29. Baingan Bharta ────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 29; r.diet = VEGAN; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 30; r.default_servings = 2;
    strncpy(r.name, "Baingan Bharta", MAX_NAME_LEN - 1);
    strncpy(r.description, "Smoky roasted aubergine mashed and cooked with onion, tomato and spices. The smoky flavour is the soul of this dish.", MAX_STR_LEN - 1);
    tmp = ing("aubergine", "1 large"); add_alias(&tmp, "baingan"); add_alias(&tmp, "eggplant"); add_alias(&tmp, "brinjal"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("garlic", "5 cloves, minced"); add_alias(&tmp, "lahsun"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, finely chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rub the whole aubergine with oil. Roast directly over a gas flame, turning with tongs every 2 minutes, until the skin is completely charred and the inside is soft, about 15 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Place the roasted aubergine in a bowl and cover for 10 minutes. Peel off all the charred skin under running water. Mash the flesh thoroughly with a fork.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 2 tablespoons oil. Add cumin seeds. Add onion, garlic, ginger and green chillies and cook for 7 minutes until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add tomatoes, turmeric, red chilli powder and salt. Cook 7 minutes. Add mashed aubergine, mix well and cook for 5 more minutes. Add garam masala. Serve with roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "aubergine", 63); strncpy(r.tags[1], "smoky", 63); strncpy(r.tags[2], "vegan", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 30. Aloo Palak ────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 30; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Aloo Palak", MAX_NAME_LEN - 1);
    strncpy(r.description, "Potatoes cooked in a fresh spinach gravy. Nutritious, vibrant green and wonderfully comforting.", MAX_STR_LEN - 1);
    tmp = ing("potato", "2 medium, boiled and cubed"); add_alias(&tmp, "aloo"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("spinach", "250g, blanched and pureed"); add_alias(&tmp, "palak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "1 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Blanch 250g spinach in boiling water for 2 minutes. Drain, cool in cold water and blend to a smooth puree.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat ghee, add cumin. Add onion and cook 5 minutes. Add ginger-garlic paste and tomato with spices. Cook 7 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add spinach puree, boiled potato cubes and salt. Simmer 8 minutes. Add garam masala and serve.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "spinach", 63); strncpy(r.tags[1], "potato", 63); strncpy(r.tags[2], "iron-rich", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 31. Mix Vegetable Curry ───────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 31; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 25; r.default_servings = 2;
    strncpy(r.name, "Mix Vegetable Curry", MAX_NAME_LEN - 1);
    strncpy(r.description, "A medley of colourful vegetables in a lightly spiced tomato-based gravy. Versatile, healthy and satisfying.", MAX_STR_LEN - 1);
    tmp = ing("mixed vegetables", "2.5 cups (carrot, potato, beans, peas, capsicum)"); add_alias(&tmp, "sabzi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashew paste", "2 tablespoons (optional, for creaminess)"); add_alias(&tmp, "kaju"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Cut all vegetables into uniform 1-inch pieces. Par-boil harder vegetables like carrot and potato for 5 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat oil, add cumin seeds. Saute onion until golden, add ginger-garlic paste and cook 2 minutes. Add tomato puree and spices, cook 8 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add all vegetables and cashew paste if using. Add 3/4 cup water and salt. Cover and cook 10 minutes until vegetables are tender. Add garam masala and serve.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "vegetables", 63); strncpy(r.tags[1], "healthy", 63); strncpy(r.tags[2], "versatile", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 32. Kadhi Pakora ──────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 32; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 35; r.default_servings = 2;
    strncpy(r.name, "Kadhi Pakora", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tangy curd-based curry with crispy chickpea flour fritters. Comfort food at its finest, served over rice.", MAX_STR_LEN - 1);
    tmp = ing("curd", "1.5 cups, slightly sour"); add_alias(&tmp, "yogurt"); add_alias(&tmp, "dahi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("chickpea flour", "5 tablespoons"); add_alias(&tmp, "besan"); add_alias(&tmp, "gram flour"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, slit"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons for curry, more for frying pakoras"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Make pakora batter: Mix 3 tablespoons besan with water to a thick batter. Add salt, red chilli powder and onion. Deep fry small spoonfuls in hot oil until golden. Drain and set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Whisk together curd, 2 tablespoons besan, turmeric, red chilli powder, salt and 2 cups water until smooth with no lumps.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 3 tablespoons oil in a pot. Add mustard seeds, dry red chillies, curry leaves, ginger and green chillies. Stir for 1 minute.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add the curd-besan mixture and cook, stirring continuously on medium heat for 20 to 25 minutes until the kadhi thickens. It should coat the back of a spoon.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the pakoras to the kadhi, simmer 5 minutes and serve over steamed rice.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "kadhi", 63); strncpy(r.tags[1], "curd", 63); strncpy(r.tags[2], "comfort food", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 33. Pav Bhaji ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 33; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = WEST_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 30; r.default_servings = 2;
    strncpy(r.name, "Pav Bhaji", MAX_NAME_LEN - 1);
    strncpy(r.description, "Mumbai's iconic street food — a thick, buttery mixed vegetable mash served with buttered and toasted pav rolls.", MAX_STR_LEN - 1);
    tmp = ing("potato", "3 medium, boiled and mashed"); add_alias(&tmp, "aloo"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cauliflower", "1 cup, boiled and mashed"); add_alias(&tmp, "gobi"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green peas", "1/2 cup, boiled"); add_alias(&tmp, "matar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("capsicum", "1/2, finely chopped"); add_alias(&tmp, "shimla mirch"); add_alias(&tmp, "bell pepper"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 large, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("pav bhaji masala", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("butter", "4 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("pav bread rolls", "4 rolls"); add_alias(&tmp, "bread rolls"); add_alias(&tmp, "dinner rolls"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat 2 tablespoons butter in a large flat pan. Add chopped onion and cook for 7 minutes until golden. Add ginger-garlic paste and cook 2 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add chopped capsicum and cook 3 minutes. Add chopped tomatoes, turmeric and red chilli powder. Cook 8 minutes until tomatoes break down.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add all the mashed vegetables (potato, cauliflower, peas) and 2 tablespoons pav bhaji masala. Mix and mash everything together with a masher.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add 1 cup water and salt. Cook and mash on medium heat for 10 minutes until bhaji is thick and uniform. Add remaining butter.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Toast pav rolls cut-side down on a hot buttered pan until golden. Serve bhaji with toasted pav, chopped onion and lemon wedges.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "street food", 63); strncpy(r.tags[1], "mumbai", 63); strncpy(r.tags[2], "vegetables", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 34. Chole Bhature ─────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 34; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 40; r.default_servings = 2;
    strncpy(r.name, "Chole Bhature", MAX_NAME_LEN - 1);
    strncpy(r.description, "Spicy Punjabi chole (chickpea curry) served with fluffy deep-fried bhature bread. A legendary combination.", MAX_STR_LEN - 1);
    tmp = ing("chickpeas", "1.5 cups, soaked overnight"); add_alias(&tmp, "chole"); add_alias(&tmp, "chana"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 large, chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 large, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("chole masala powder", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("maida flour", "2 cups for bhature"); add_alias(&tmp, "all purpose flour"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "3 tablespoons for bhature"); add_alias(&tmp, "yogurt"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons + for deep frying"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "2 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Pressure cook soaked chickpeas with 3 cups water, 1 teaspoon salt and a tea bag for dark colour, for 6 whistles. Discard tea bag.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Make bhature dough: Mix 2 cups maida, curd, 1 teaspoon oil and salt with enough water to make a soft dough. Rest 30 minutes covered.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Make chole: Heat 3 tablespoons oil. Cook onion 10 minutes golden. Add ginger-garlic paste 2 minutes. Add tomato puree, all spices and salt. Cook 10 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add cooked chickpeas with 1 cup cooking liquid. Mash a few chickpeas. Simmer 15 minutes until thick.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Roll bhature dough into oval shapes 1/4 inch thick. Deep fry in hot oil, pressing gently so they puff up, until golden on both sides. Drain and serve immediately with chole.", MAX_STEP_LEN - 1);
    r.step_count = 5;
    strncpy(r.tags[0], "chickpeas", 63); strncpy(r.tags[1], "punjabi", 63); strncpy(r.tags[2], "festive", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 35. Dal Makhani ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 35; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 60; r.default_servings = 2;
    strncpy(r.name, "Dal Makhani", MAX_NAME_LEN - 1);
    strncpy(r.description, "Slow-cooked black lentils and kidney beans in a rich, creamy butter-tomato sauce. The jewel of Punjabi cuisine.", MAX_STR_LEN - 1);
    tmp = ing("whole black lentils", "3/4 cup, soaked overnight"); add_alias(&tmp, "urad dal whole"); add_alias(&tmp, "sabut urad"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("kidney beans", "1/4 cup, soaked overnight"); add_alias(&tmp, "rajma"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 large, pureed"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh cream", "4 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("butter", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("kasuri methi", "1 teaspoon"); add_alias(&tmp, "dried fenugreek"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Pressure cook soaked black lentils and kidney beans together with 3 cups water, 1/2 teaspoon salt and 1/4 teaspoon turmeric for 8 to 10 whistles until completely soft.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Mash a quarter of the cooked lentils to give the dal body. Set aside.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat 3 tablespoons butter in a heavy pot. Add onion and cook for 7 minutes until golden. Add ginger-garlic paste and cook 2 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add tomato puree, red chilli powder and salt. Cook for 12 minutes on medium heat until butter separates from the tomato masala.", MAX_STEP_LEN - 1);
    strncpy(r.steps[4], "Add the cooked lentils and mix well. Simmer on the lowest heat for 30 minutes, stirring every 5 minutes to prevent sticking. The long simmer develops the deep flavour.", MAX_STEP_LEN - 1);
    strncpy(r.steps[5], "Add fresh cream, garam masala and crushed kasuri methi. Stir gently, simmer 5 more minutes. Serve with naan or rice.", MAX_STEP_LEN - 1);
    r.step_count = 6;
    strncpy(r.tags[0], "dal", 63); strncpy(r.tags[1], "slow cooked", 63); strncpy(r.tags[2], "creamy", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 36. Methi Chicken ─────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 36; r.diet = NON_VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 35; r.default_servings = 2;
    strncpy(r.name, "Methi Chicken", MAX_NAME_LEN - 1);
    strncpy(r.description, "Chicken cooked with fresh or dried fenugreek leaves, lending a pleasantly bitter, herbaceous flavour.", MAX_STR_LEN - 1);
    tmp = ing("chicken", "500g, curry cut"); add_alias(&tmp, "murgh"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh fenugreek leaves", "1 cup, washed and chopped"); add_alias(&tmp, "methi"); add_alias(&tmp, "fenugreek"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "2 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curd", "3 tablespoons"); add_alias(&tmp, "yogurt"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1.5 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("coriander powder", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("garam masala", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat oil, add cumin seeds. Add onion and cook 8 minutes until golden. Add ginger-garlic paste and cook 2 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add tomatoes and all spices. Cook 8 minutes. Add chicken and cook on high heat 5 minutes to seal the pieces.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add whisked curd on low heat, stir quickly. Add chopped fenugreek leaves and 1/2 cup water. Cover and cook 20 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Add garam masala, adjust salt, simmer 5 minutes uncovered. Serve with roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "chicken", 63); strncpy(r.tags[1], "fenugreek", 63); strncpy(r.tags[2], "herbaceous", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 37. Sarson Ka Saag ────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 37; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = NORTH_INDIAN;
    r.prep_time_min = 15; r.cook_time_min = 45; r.default_servings = 2;
    strncpy(r.name, "Sarson Ka Saag", MAX_NAME_LEN - 1);
    strncpy(r.description, "Winter classic of slow-cooked mustard greens and spinach, finished with ghee and served with makki roti.", MAX_STR_LEN - 1);
    tmp = ing("mustard greens", "400g, washed and chopped"); add_alias(&tmp, "sarson"); add_alias(&tmp, "mustard leaves"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("spinach", "150g, washed and chopped"); add_alias(&tmp, "palak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 large, chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "1 medium, chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "2 inches, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("garlic", "6 cloves, minced"); add_alias(&tmp, "lahsun"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("maize flour", "2 tablespoons"); add_alias(&tmp, "makki ka atta"); add_alias(&tmp, "corn flour"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "3 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Pressure cook mustard greens, spinach, onion, tomato, ginger, garlic and 1/2 cup water for 3 whistles. Let steam release naturally.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Using a hand blender or potato masher, blend the cooked greens to a coarse (not fully smooth) consistency.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add 2 tablespoons maize flour, turmeric, red chilli powder and salt. Stir well and cook on low heat for 20 minutes, stirring often.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Heat 3 tablespoons ghee in a small pan. Add minced garlic and let it turn golden. Pour this ghee tadka over the saag and mix gently. Serve with makki di roti.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "mustard greens", 63); strncpy(r.tags[1], "winter", 63); strncpy(r.tags[2], "punjabi", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 38. Coconut Rice ──────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 38; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 5; r.cook_time_min = 10; r.default_servings = 2;
    strncpy(r.name, "Coconut Rice", MAX_NAME_LEN - 1);
    strncpy(r.description, "Fluffy rice tossed with freshly grated coconut and tempered with South Indian spices. Quick, fragrant and delicious.", MAX_STR_LEN - 1);
    tmp = ing("cooked rice", "2 cups"); add_alias(&tmp, "rice"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("fresh grated coconut", "1/2 cup"); add_alias(&tmp, "nariyal"); add_alias(&tmp, "coconut"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("cashews", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("urad dal", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("chana dal", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat oil, add mustard seeds, let splutter. Add urad dal and chana dal, stir 30 seconds until golden. Add cashews and roast until golden.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add dried red chillies and curry leaves. Stir 20 seconds. Add grated coconut and toss for 1 minute on medium heat.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add cooked rice and salt. Gently mix to coat every grain with the coconut tempering. Serve warm.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "coconut", 63); strncpy(r.tags[1], "south indian", 63); strncpy(r.tags[2], "quick", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 39. Tomato Rice ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 39; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Tomato Rice", MAX_NAME_LEN - 1);
    strncpy(r.description, "Tangy South Indian tomato rice with mustard seeds, curry leaves and bold spices. A one-pot favourite.", MAX_STR_LEN - 1);
    tmp = ing("rice", "1 cup, cooked"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "3 large, finely chopped"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("onion", "1 medium, finely chopped"); add_alias(&tmp, "pyaaz"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger-garlic paste", "1 tablespoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("dry red chilli", "2 pieces"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("red chilli powder", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Heat oil, add mustard seeds, dry red chillies and curry leaves. Let splutter. Add onion and cook 5 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add ginger-garlic paste and cook 2 minutes. Add tomatoes, turmeric, red chilli powder and salt. Cook 10 minutes until tomatoes break down into a thick masala.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add cooked rice and gently mix until every grain is coated with the tomato masala. Serve with papad and raita.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "tomato", 63); strncpy(r.tags[1], "rice", 63); strncpy(r.tags[2], "south indian", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 40. Vegetable Khichdi ─────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 40; r.diet = VEG; r.meal = MAIN_COURSE; r.cuisine = PAN_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Vegetable Khichdi", MAX_NAME_LEN - 1);
    strncpy(r.description, "Soft, comforting one-pot rice and lentil porridge with vegetables and mild spices. The ultimate Indian comfort meal.", MAX_STR_LEN - 1);
    tmp = ing("rice", "1/2 cup"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("moong dal", "1/2 cup, yellow split"); add_alias(&tmp, "split yellow lentils"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mixed vegetables", "1 cup (carrot, peas, potato)"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "1, slit"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("asafoetida", "a pinch"); add_alias(&tmp, "hing"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("ghee", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("cumin seeds", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/2 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Rinse rice and moong dal together thoroughly. Soak for 15 minutes, then drain.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Heat ghee in a pressure cooker. Add cumin seeds and a pinch of asafoetida. Add ginger and green chilli and stir 30 seconds.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add mixed vegetables and saute 2 minutes. Add rice-dal mixture, turmeric, salt and 3.5 cups water. Pressure cook for 3 whistles.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Let pressure release naturally. The khichdi should be soft and porridge-like. Serve hot with ghee, pickle and papad.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "comfort food", 63); strncpy(r.tags[1], "one-pot", 63); strncpy(r.tags[2], "light", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 41. Idli Sambar ───────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 41; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 10; r.cook_time_min = 15; r.default_servings = 2;
    strncpy(r.name, "Idli Sambar", MAX_NAME_LEN - 1);
    strncpy(r.description, "Soft steamed rice cakes served with piping hot sambar. South India's most iconic breakfast combination.", MAX_STR_LEN - 1);
    tmp = ing("idli batter", "2 cups, ready-made or fermented"); add_alias(&tmp, "rice batter"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("toor dal", "1/2 cup for sambar"); add_alias(&tmp, "arhar dal"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tomato", "2 medium, quartered"); add_alias(&tmp, "tamatar"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("sambar powder", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("tamarind", "small ball soaked in water"); add_alias(&tmp, "imli"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("oil", "2 tablespoons"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("mustard seeds", "1 teaspoon"); add_alias(&tmp, "rai"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("turmeric powder", "1/4 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1.5 teaspoons"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Grease idli moulds with oil. Fill each mould with idli batter till 3/4 full. Steam for 10 to 12 minutes until a toothpick comes out clean. Rest 2 minutes before demoulding.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Cook sambar: Pressure cook toor dal for 4 whistles. Mash. Heat oil, add mustard seeds, curry leaves. Add tomatoes, sambar powder, tamarind extract and turmeric. Cook 8 minutes.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Add mashed dal to the tomato mixture with 1.5 cups water and salt. Simmer 10 minutes. Serve idlis with hot sambar and coconut chutney.", MAX_STEP_LEN - 1);
    r.step_count = 3;
    strncpy(r.tags[0], "idli", 63); strncpy(r.tags[1], "breakfast", 63); strncpy(r.tags[2], "south indian", 63); r.tag_count = 3;
    add_recipe(db, r);

    /* ── 42. Medu Vada ─────────────────────────────────────────── */
    memset(&r, 0, sizeof(Recipe));
    r.id = 42; r.diet = VEG; r.meal = BREAKFAST; r.cuisine = SOUTH_INDIAN;
    r.prep_time_min = 20; r.cook_time_min = 20; r.default_servings = 2;
    strncpy(r.name, "Medu Vada", MAX_NAME_LEN - 1);
    strncpy(r.description, "Crispy on the outside, fluffy on the inside doughnut-shaped urad dal fritters. Served with sambar and chutney.", MAX_STR_LEN - 1);
    tmp = ing("urad dal", "1 cup, soaked 4 hours"); add_alias(&tmp, "split black lentils"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("ginger", "1 inch, grated"); add_alias(&tmp, "adrak"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("green chilli", "2, finely chopped"); add_alias(&tmp, "hari mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("curry leaves", "10 leaves, chopped"); add_alias(&tmp, "kadi patta"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("black pepper", "1/2 teaspoon, coarsely crushed"); add_alias(&tmp, "kali mirch"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = ing("oil", "for deep frying"); r.ingredients[r.ingredient_count++] = tmp;
    tmp = staple("salt", "1 teaspoon"); r.ingredients[r.ingredient_count++] = tmp;
    strncpy(r.steps[0], "Drain soaked urad dal and grind with minimal water (2 to 3 tablespoons) to a thick, fluffy batter. The batter should be smooth and hold its shape.", MAX_STEP_LEN - 1);
    strncpy(r.steps[1], "Add ginger, green chillies, curry leaves, black pepper and salt to the batter. Mix well. Beat the batter vigorously for 2 minutes to incorporate air.", MAX_STEP_LEN - 1);
    strncpy(r.steps[2], "Heat oil for deep frying to 180C. Wet your hands, take a ball of batter and shape into a disc. Make a hole in the centre. Gently slide into the hot oil.", MAX_STEP_LEN - 1);
    strncpy(r.steps[3], "Fry 4 to 5 vadas at a time for 3 to 4 minutes per side until deep golden and crispy. Drain on paper towels. Serve hot with sambar and coconut chutney.", MAX_STEP_LEN - 1);
    r.step_count = 4;
    strncpy(r.tags[0], "vada", 63); strncpy(r.tags[1], "breakfast", 63); strncpy(r.tags[2], "crispy", 63); r.tag_count = 3;
    add_recipe(db, r);
}
